<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
$pageTitle = 'Menu';

$search = trim($_GET['search'] ?? '');
$categoryId = $_GET['category'] ?? '';
$categories = $pdo->query("SELECT * FROM categories WHERE status = 'Active' ORDER BY name")->fetchAll();

$sql = "SELECT f.*, c.name AS category_name, COALESCE((SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.food_id = f.id), f.rating) AS display_rating FROM food_items f JOIN categories c ON c.id = f.category_id WHERE f.status = 'Available'";
$params = [];
if ($search !== '') {
    $sql .= " AND f.name LIKE ?";
    $params[] = "%$search%";
}
if ($categoryId !== '') {
    $sql .= " AND f.category_id = ?";
    $params[] = $categoryId;
}
$sql .= " ORDER BY f.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$foods = $stmt->fetchAll();
include 'includes/header.php';
?>
<section class="page-header menu-hero">
    <div class="container">
        <h1 class="fw-bold">Menu</h1>
        <p class="lead mb-0">Find your next favorite dish and add it to cart instantly.</p>
    </div>
</section>
<section class="search-panel">
    <div class="container">
        <form class="row g-3 content-card p-3">
            <div class="col-md-6"><input name="search" class="form-control" placeholder="Search food name" value="<?= e($search) ?>"></div>
            <div class="col-md-4">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id'] ?>" <?= $categoryId == $category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2"><button class="btn btn-brand w-100">Filter</button></div>
        </form>
    </div>
</section>
<section class="py-5">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-4">
            <div>
                <h2 class="fw-bold mb-1">Available Dishes</h2>
                <p class="text-secondary mb-0"><?= count($foods) ?> items found. Freshly prepared and ready to order.</p>
            </div>
            <a href="cart.php" class="btn btn-outline-dark btn-sm"><i class="bi bi-bag"></i> View Cart</a>
        </div>
        <div class="row g-4">
            <?php foreach ($foods as $food): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="food-card">
                        <div class="food-img-wrap">
                            <img src="<?= e(food_image($food['image'])) ?>" alt="<?= e($food['name']) ?>">
                        </div>
                        <div class="p-3">
                            <div class="d-flex justify-content-between">
                                <span class="badge text-bg-light"><?= e($food['category_name']) ?></span>
                                <span class="rating-chip"><i class="bi bi-star-fill"></i> <?= e($food['display_rating']) ?></span>
                            </div>
                            <h5 class="fw-bold mt-3"><?= e($food['name']) ?></h5>
                            <p class="text-secondary small"><?= e($food['description']) ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <strong class="food-price"><?= money($food['price']) ?></strong>
                                <button class="btn btn-brand btn-sm" onclick="addToCart(<?= $food['id'] ?>)">Add to Cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if (!$foods): ?>
                <div class="col-12"><div class="empty-state">No food items found. Try another search or category.</div></div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
