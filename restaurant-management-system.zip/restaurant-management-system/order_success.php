<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Order Confirmed';
$orderId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) redirect('orders.php');
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container text-center">
        <i class="bi bi-check-circle-fill text-success display-1"></i>
        <h1 class="fw-bold mt-3">Order Confirmed</h1>
        <p class="lead">Your order #<?= $order['id'] ?> has been placed successfully.</p>
        <p class="fw-bold"><?= money($order['total_amount']) ?> via <?= e($order['payment_method']) ?></p>
        <?php if ($order['payment_method'] === 'UPI Payment'): ?>
            <p class="text-secondary">UPI Reference: <?= e($order['transaction_id']) ?> | Payment: <?= e($order['payment_status']) ?></p>
        <?php endif; ?>
        <a href="track_order.php?id=<?= $order['id'] ?>" class="btn btn-brand">Track Order</a>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
