function updateCartCount() {
    const counter = document.getElementById('cart-count');
    if (!counter) return;

    fetch('ajax/cart_action.php?action=count')
        .then(response => response.json())
        .then(data => {
            counter.textContent = data.count ?? 0;
        })
        .catch(() => {});
}

function addToCart(foodId) {
    const formData = new FormData();
    formData.append('food_id', foodId);

    fetch('ajax/cart_action.php?action=add', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) updateCartCount();
        })
        .catch(() => alert('Unable to update cart right now.'));
}

function updateCartItem(cartId, quantity) {
    const formData = new FormData();
    formData.append('cart_id', cartId);
    formData.append('quantity', quantity);

    fetch('ajax/cart_action.php?action=update', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(() => window.location.reload());
}

function removeCartItem(cartId) {
    if (!confirm('Remove this item from cart?')) return;

    const formData = new FormData();
    formData.append('cart_id', cartId);

    fetch('ajax/cart_action.php?action=remove', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(() => window.location.reload());
}

document.addEventListener('DOMContentLoaded', updateCartCount);
