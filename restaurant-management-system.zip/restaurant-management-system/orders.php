<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Order History';
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();
include 'includes/header.php';
?>
<section class="py-5 section-band"><div class="container"><h1 class="fw-bold">Order History</h1></div></section>
<section class="py-5">
    <div class="container content-card p-3">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Order</th><th>Date</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?= $order['id'] ?></td>
                        <td><?= e($order['created_at']) ?></td>
                        <td><?= money($order['total_amount']) ?></td>
                        <td><?= order_status_badge($order['status']) ?></td>
                        <td>
                            <a href="track_order.php?id=<?= $order['id'] ?>" class="btn btn-outline-dark btn-sm">Track</a>
                            <a href="invoice.php?id=<?= $order['id'] ?>" class="btn btn-outline-dark btn-sm">Invoice</a>
                            <a href="order_action.php?action=reorder&id=<?= $order['id'] ?>" class="btn btn-outline-success btn-sm">Reorder</a>
                            <?php if ($order['status'] === 'Pending'): ?>
                                <a href="order_action.php?action=cancel&id=<?= $order['id'] ?>" onclick="return confirm('Cancel this order?')" class="btn btn-outline-danger btn-sm">Cancel</a>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'Delivered'): ?>
                                <a href="review_order.php?id=<?= $order['id'] ?>" class="btn btn-brand btn-sm">Review</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$orders): ?>
                    <tr><td colspan="5"><div class="empty-state">No orders yet. Start with the menu and place your first order.</div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
