<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
$pageTitle = 'BCA Bistro - Restaurant Management System';

$featured = $pdo->query("SELECT f.*, c.name AS category_name, COALESCE((SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.food_id = f.id), f.rating) AS display_rating FROM food_items f JOIN categories c ON c.id = f.category_id WHERE f.status = 'Available' ORDER BY display_rating DESC LIMIT 6")->fetchAll();
$categories = $pdo->query("SELECT * FROM categories WHERE status = 'Active' ORDER BY name")->fetchAll();
$categoryIcons = [
    'Veg' => 'bi-flower1',
    'Non-Veg' => 'bi-fire',
    'Drinks' => 'bi-cup-straw',
    'Desserts' => 'bi-cake2',
];
include 'includes/header.php';
?>
<section class="hero-section">
    <div class="container">
        <div class="col-lg-7">
            <span class="badge text-bg-light text-brand mb-3">Final Year BCA Project</span>
            <h1>Restaurant ordering made fast, fresh, and simple.</h1>
            <p class="lead mt-3">Browse dishes, add to cart, place orders, track delivery, and manage your restaurant from one system.</p>
            <div class="d-flex flex-wrap gap-3 mt-4">
                <a href="menu.php" class="btn btn-brand btn-lg">Order Now</a>
                <a href="login.php" class="btn btn-light btn-lg">Track Orders</a>
            </div>
            <div class="hero-metrics mt-4">
                <div class="hero-metric"><strong>25 min</strong><span>Average delivery</span></div>
                <div class="hero-metric"><strong>4.7</strong><span>Customer rating</span></div>
                <div class="hero-metric"><strong>100%</strong><span>Fresh kitchen</span></div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 section-band">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div class="section-title">
                <h2 class="fw-bold mb-1">Popular Categories</h2>
                <p class="text-secondary mb-0">Pick a craving and jump straight into the menu.</p>
            </div>
        </div>
        <div class="row g-3">
            <?php foreach ($categories as $category): ?>
                <div class="col-6 col-md-3">
                    <a href="menu.php?category=<?= $category['id'] ?>" class="text-decoration-none text-dark">
                        <div class="category-pill d-flex align-items-center gap-3">
                            <span class="category-icon"><i class="bi <?= e($categoryIcons[$category['name']] ?? 'bi-grid-fill') ?>"></i></span>
                            <span class="fw-semibold flex-grow-1"><?= e($category['name']) ?></span>
                            <i class="bi bi-arrow-right text-brand"></i>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div class="section-title">
                <h2 class="fw-bold mb-1">Featured Food</h2>
                <p class="text-secondary mb-0">Fresh picks with customer-favorite ratings.</p>
            </div>
            <a href="menu.php" class="btn btn-outline-dark btn-sm">View Full Menu</a>
        </div>
        <div class="row g-4">
            <?php foreach ($featured as $food): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="food-card">
                        <div class="food-img-wrap">
                            <img src="<?= e(food_image($food['image'])) ?>" alt="<?= e($food['name']) ?>">
                        </div>
                        <div class="p-3">
                            <div class="d-flex justify-content-between">
                                <span class="badge text-bg-light"><?= e($food['category_name']) ?></span>
                                <span class="rating-chip"><i class="bi bi-star-fill"></i> <?= e($food['display_rating']) ?></span>
                            </div>
                            <h5 class="fw-bold mt-3"><?= e($food['name']) ?></h5>
                            <p class="text-secondary small"><?= e($food['description']) ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <strong class="food-price"><?= money($food['price']) ?></strong>
                                <button class="btn btn-brand btn-sm" onclick="addToCart(<?= $food['id'] ?>)">Add</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<section class="py-5 section-band">
    <div class="container">
        <div class="section-title mb-4">
            <h2 class="fw-bold mb-1">How It Works</h2>
            <p class="text-secondary mb-0">A simple flow that is easy to use and easy to explain in viva.</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon"><i class="bi bi-search"></i></div>
                    <h5 class="fw-bold">Choose Food</h5>
                    <p class="text-secondary mb-0">Search dishes, filter categories, and add favorites to the cart.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon"><i class="bi bi-phone"></i></div>
                    <h5 class="fw-bold">Pay Online</h5>
                    <p class="text-secondary mb-0">Use UPI payment or cash on delivery and save order details.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon"><i class="bi bi-truck"></i></div>
                    <h5 class="fw-bold">Track Status</h5>
                    <p class="text-secondary mb-0">Follow order progress from pending to delivered.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="py-5">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-lg-5">
                <div class="section-title">
                    <span class="badge text-bg-light text-brand mb-2">Smart Restaurant System</span>
                    <h2 class="fw-bold mb-3">Built for customers, kitchen staff, and admin control.</h2>
                    <p class="text-secondary mb-0">Every part of the system is connected: menu, cart, UPI payment, invoice, booking, reviews, reports, and order tracking.</p>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="feature-card">
                            <div class="feature-icon"><i class="bi bi-receipt"></i></div>
                            <h5 class="fw-bold">Invoices</h5>
                            <p class="text-secondary mb-0">Printable bills with GST, delivery and discount details.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="feature-card">
                            <div class="feature-icon"><i class="bi bi-graph-up-arrow"></i></div>
                            <h5 class="fw-bold">Reports</h5>
                            <p class="text-secondary mb-0">Admin can check revenue, orders, bookings and sales trends.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
