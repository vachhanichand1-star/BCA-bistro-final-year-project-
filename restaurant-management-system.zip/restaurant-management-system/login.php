<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
$pageTitle = 'User Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && verify_password_with_plaintext_upgrade($password, $user['password'], 'users', $user['id'], $pdo)) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        redirect('index.php');
    }

    flash('error', 'Invalid email or password.');
}
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container">
        <div class="col-lg-5 mx-auto auth-card p-4">
            <h2 class="fw-bold mb-3">Login</h2>
            <form method="post">
                <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="user@example.com" required></div>
                <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" value="user123" required></div>
                <button class="btn btn-brand w-100">Login</button>
            </form>
            <div class="d-flex justify-content-between mt-3">
                <a href="register.php">Create account</a>
                <a href="forgot_password.php">Forgot password?</a>
            </div>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
