# Restaurant Management System

Final Year BCA major project built with HTML5, CSS3, Bootstrap 5, JavaScript, Core PHP, MySQL and XAMPP.

## Folder Structure

```text
restaurant-management-system/
|-- admin/
|   |-- bookings.php
|   |-- categories.php
|   |-- coupons.php
|   |-- dashboard.php
|   |-- foods.php
|   |-- index.php
|   |-- login.php
|   |-- logout.php
|   |-- orders.php
|   |-- reports.php
|   |-- settings.php
|   |-- users.php
|-- ajax/
|   |-- cart_action.php
|   |-- order_status.php
|-- assets/
|   |-- css/style.css
|   |-- js/app.js
|-- config/
|   |-- database.php
|   |-- helpers.php
|-- database/
|   |-- restaurant_management.sql
|-- includes/
|   |-- admin_footer.php
|   |-- admin_header.php
|   |-- footer.php
|   |-- header.php
|-- uploads/
|   |-- food/
|-- book_table.php
|-- cart.php
|-- checkout.php
|-- forgot_password.php
|-- index.php
|-- invoice.php
|-- login.php
|-- logout.php
|-- menu.php
|-- order_action.php
|-- order_success.php
|-- orders.php
|-- profile.php
|-- register.php
|-- review_order.php
|-- track_order.php
```

## Main Features

- User registration and session-based login
- Homepage with modern restaurant banner, featured foods and categories
- Menu search and category filter
- Dynamic ratings from customer reviews
- AJAX add/update/remove cart
- Checkout with delivery address, UPI payment, cash on delivery and coupon code
- GST calculation, delivery charge and free delivery threshold
- Printable invoice page
- Order confirmation and live AJAX order tracking
- User order history, cancel pending order and reorder previous order
- User profile and table booking request
- Separate admin login
- Admin dashboard with totals, recent orders, recent bookings and Chart.js sales graph
- Category CRUD
- Food CRUD with image upload
- Coupon management
- Website settings for restaurant details, UPI ID, GST and delivery charges
- Order management with status updates
- Table booking management with confirm/cancel/delete actions
- User management
- Daily and monthly sales reports

## Database Tables

- `users`
- `admin`
- `categories`
- `food_items`
- `cart`
- `orders`
- `order_items`
- `reviews`
- `coupons`
- `settings`
- `table_bookings`

## Setup Instructions For XAMPP

1. Copy the `restaurant-management-system` folder into:

   ```text
   C:\xampp\htdocs\
   ```

2. Start XAMPP Control Panel.

3. Start `Apache` and `MySQL`.

4. Open phpMyAdmin:

   ```text
   http://localhost/phpmyadmin
   ```

5. Click `Import`.

6. Select this SQL file:

   ```text
   restaurant-management-system/database/restaurant_management.sql
   ```

7. Click `Go`.

8. Open the user website:

   ```text
   http://localhost/restaurant-management-system/
   ```

9. Open the admin panel:

   ```text
   http://localhost/restaurant-management-system/admin/
   ```

Important: if you imported an older version of this project, drop the old `restaurant_management` database and import the latest SQL again because new columns and tables were added.

Quick fix for missing-table errors:

```text
http://localhost/restaurant-management-system/setup_database.php
```

This setup page imports `database/restaurant_management.sql` directly from the browser.

## Demo Logins

User:

```text
Email: user@example.com
Password: user123
```

Admin:

```text
Username: admin
Password: admin123
```

The sample SQL stores demo passwords in plain text only so the project runs immediately after import. On first successful login, the PHP code automatically upgrades that password to a secure hash.

## Coupon Codes

```text
BCA10  - 10% discount, minimum order Rs. 199
FOOD20 - 20% discount, minimum order Rs. 499
```

## UPI Payment Demo

The checkout page includes a UPI payment option. The UPI ID is controlled by admin from `Settings`.

Default UPI ID:

```text
bca-bistro@upi
```

When the customer selects UPI, the system opens a UPI payment link on supported devices and asks for the UPI transaction/reference ID. That reference is saved in the `orders` table so the admin can verify it from the order management page.

## New Major Project Features Added

- Admin coupon CRUD with minimum order amount and expiry date
- Website settings panel
- GST and delivery charge calculation
- Printable invoice
- Live AJAX order tracking
- Delivered-order reviews and dynamic ratings
- Cancel pending order and reorder previous order

## Notes For Viva

- The project uses prepared statements with PDO to reduce SQL injection risk.
- Sessions are used for user and admin authentication.
- The UI uses Bootstrap 5 with custom CSS for a modern restaurant application look.
- Admin and user panels are separated.
- The customer navbar does not expose the admin panel; admin opens separately from `/admin/`.
- The order flow is: menu -> cart -> checkout -> order stored -> admin updates status -> user tracks order.
- UPI payment is implemented as an academic/demo gateway flow. Real automatic verification requires Razorpay, PhonePe, Paytm, Cashfree or bank merchant credentials.
