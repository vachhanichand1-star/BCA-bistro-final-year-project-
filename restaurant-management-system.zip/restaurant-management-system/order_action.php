<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();

$action = $_GET['action'] ?? '';
$orderId = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    flash('error', 'Order not found.');
    redirect('orders.php');
}

if ($action === 'cancel') {
    if ($order['status'] === 'Pending') {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'Cancelled' WHERE id = ? AND user_id = ?");
        $stmt->execute([$orderId, $_SESSION['user_id']]);
        flash('success', 'Order cancelled successfully.');
    } else {
        flash('error', 'Only pending orders can be cancelled.');
    }
    redirect('orders.php');
}

if ($action === 'reorder') {
    $items = $pdo->prepare("SELECT food_id, quantity FROM order_items WHERE order_id = ?");
    $items->execute([$orderId]);
    $cartStmt = $pdo->prepare("INSERT INTO cart (user_id, food_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
    foreach ($items->fetchAll() as $item) {
        $cartStmt->execute([$_SESSION['user_id'], $item['food_id'], $item['quantity']]);
    }
    flash('success', 'Previous order items added to cart.');
    redirect('cart.php');
}

redirect('orders.php');
?>
