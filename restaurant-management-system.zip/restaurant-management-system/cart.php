<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Cart';

$stmt = $pdo->prepare("SELECT cart.id AS cart_id, cart.quantity, f.name, f.price, f.image FROM cart JOIN food_items f ON f.id = cart.food_id WHERE cart.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$items = $stmt->fetchAll();
$total = 0;
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container">
        <h1 class="fw-bold">Your Cart</h1>
    </div>
</section>
<section class="py-5">
    <div class="container">
        <?php if ($items): ?>
            <div class="content-card p-3">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead><tr><th>Food</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($items as $item): $subtotal = $item['price'] * $item['quantity']; $total += $subtotal; ?>
                            <tr>
                                <td><img src="<?= e(food_image($item['image'])) ?>" alt=""> <strong class="ms-2"><?= e($item['name']) ?></strong></td>
                                <td><?= money($item['price']) ?></td>
                                <td><input type="number" min="1" value="<?= $item['quantity'] ?>" class="form-control" style="width:90px" onchange="updateCartItem(<?= $item['cart_id'] ?>, this.value)"></td>
                                <td><?= money($subtotal) ?></td>
                                <td><button class="btn btn-outline-danger btn-sm" onclick="removeCartItem(<?= $item['cart_id'] ?>)">Remove</button></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="fw-bold mb-0">Total: <?= money($total) ?></h4>
                    <a href="checkout.php" class="btn btn-brand">Proceed to Checkout</a>
                </div>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h4 class="fw-bold">Your cart is empty</h4>
                <p>Explore the menu and add something delicious.</p>
                <a href="menu.php" class="btn btn-brand">Browse Menu</a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
