<?php
// ============================================================
// razorpay_callback.php
// ============================================================
// After the user pays via Razorpay popup, the JavaScript sends
// the payment details HERE via a hidden form POST.
//
// IMPORTANT SECURITY STEP:
//   We verify the HMAC-SHA256 signature that Razorpay provides.
//   This ensures the payment response is genuine and hasn't been
//   tampered with by anyone.
//
// Flow:
//   Valid signature → update payment_status to 'Paid' → clear cart → success page
//   Invalid signature → mark as 'Failed' → failure page
// ============================================================

require_once 'config/database.php';
require_once 'config/helpers.php';
require_once 'config/razorpay.php';

require_user();

// --- Read POST data sent by JavaScript ---
$razorpay_payment_id = trim($_POST['razorpay_payment_id'] ?? '');
$razorpay_order_id   = trim($_POST['razorpay_order_id']   ?? '');
$razorpay_signature  = trim($_POST['razorpay_signature']  ?? '');
$order_id            = (int) ($_POST['order_id']          ?? 0);

// --- Basic validation ---
if (!$razorpay_payment_id || !$razorpay_order_id || !$razorpay_signature || !$order_id) {
    flash('error', 'Invalid payment response. Please contact support.');
    redirect('checkout.php');
}

// --- Make sure this order belongs to the logged-in user ---
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    flash('error', 'Order not found.');
    redirect('orders.php');
}

// --- VERIFY RAZORPAY SIGNATURE (Security Check) ---
// Razorpay signs the response using: HMAC-SHA256(razorpay_order_id + "|" + razorpay_payment_id, secret)
// We generate the same signature on our side and compare.
// If they match → payment is real. If not → someone tampered with it.
$generated_signature = hash_hmac(
    'sha256',
    $razorpay_order_id . '|' . $razorpay_payment_id,
    RAZORPAY_KEY_SECRET
);

if (hash_equals($generated_signature, $razorpay_signature)) {
    // ✅ PAYMENT IS GENUINE
    try {
        $pdo->beginTransaction();

        // Update the order: mark as Paid, save payment ID
        $pdo->prepare(
            "UPDATE orders
             SET payment_status = 'Paid',
                 payment_method = 'Razorpay',
                 transaction_id = ?,
                 razorpay_order_id = ?
             WHERE id = ?"
        )->execute([$razorpay_payment_id, $razorpay_order_id, $order_id]);

        // Update the payments table with full transaction details
        $pdo->prepare(
            "UPDATE payments
             SET razorpay_payment_id = ?,
                 razorpay_signature  = ?,
                 status              = 'paid'
             WHERE order_id = ?"
        )->execute([$razorpay_payment_id, $razorpay_signature, $order_id]);

        // Clear the user's cart (payment confirmed, order is placed)
        $pdo->prepare("DELETE FROM cart WHERE user_id = ?")
            ->execute([$_SESSION['user_id']]);

        $pdo->commit();

        // Go to success page
        redirect('payment_success.php?id=' . $order_id);

    } catch (Exception $e) {
        $pdo->rollBack();
        flash('error', 'Payment received but failed to update order. Please contact support with Payment ID: ' . $razorpay_payment_id);
        redirect('orders.php');
    }

} else {
    // ❌ INVALID SIGNATURE — payment may be fake or tampered
    // Mark as failed in the database
    $pdo->prepare("UPDATE orders SET payment_status = 'Failed' WHERE id = ?")
        ->execute([$order_id]);

    $pdo->prepare("UPDATE payments SET status = 'failed' WHERE order_id = ?")
        ->execute([$order_id]);

    redirect('payment_failed.php?id=' . $order_id);
}
