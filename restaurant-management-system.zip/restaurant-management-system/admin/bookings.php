<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Table Bookings';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE table_bookings SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], (int) $_POST['booking_id']]);
    flash('success', 'Booking status updated.');
    redirect('bookings.php');
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM table_bookings WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    flash('success', 'Booking deleted.');
    redirect('bookings.php');
}

$status = $_GET['status'] ?? '';
$sql = "SELECT b.*, u.name, u.email, u.phone FROM table_bookings b JOIN users u ON u.id = b.user_id";
$params = [];
if ($status) {
    $sql .= " WHERE b.status = ?";
    $params[] = $status;
}
$sql .= " ORDER BY b.booking_date DESC, b.booking_time DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();
include '../includes/admin_header.php';
?>
<div class="content-card p-4 mb-4">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-3 align-items-md-center">
    <div>
        <span class="badge text-bg-light text-brand mb-2">Reservations</span>
        <h1 class="fw-bold mb-1">Table Bookings</h1>
        <p class="text-secondary mb-0">Confirm, cancel or delete customer table booking requests.</p>
    </div>
    <form class="d-flex gap-2">
        <select name="status" class="form-select">
            <option value="">All Bookings</option>
            <?php foreach (['Pending','Confirmed','Cancelled'] as $option): ?>
                <option <?= $status === $option ? 'selected' : '' ?>><?= $option ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-brand">Filter</button>
    </form>
    </div>
</div>
<div class="content-card p-3 table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Contact</th>
                <th>Date</th>
                <th>Time</th>
                <th>Guests</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($bookings as $booking): ?>
            <tr>
                <td>#<?= $booking['id'] ?></td>
                <td><?= e($booking['name']) ?><br><small class="text-secondary"><?= e($booking['email']) ?></small></td>
                <td><?= e($booking['phone']) ?></td>
                <td><?= e($booking['booking_date']) ?></td>
                <td><?= e(substr($booking['booking_time'], 0, 5)) ?></td>
                <td><?= e($booking['guests']) ?></td>
                <td><span class="badge text-bg-<?= $booking['status'] === 'Confirmed' ? 'success' : ($booking['status'] === 'Cancelled' ? 'danger' : 'warning') ?>"><?= e($booking['status']) ?></span></td>
                <td>
                    <form method="post" class="d-flex gap-2 mb-2">
                        <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                        <select name="status" class="form-select form-select-sm">
                            <?php foreach (['Pending','Confirmed','Cancelled'] as $option): ?>
                                <option <?= $booking['status'] === $option ? 'selected' : '' ?>><?= $option ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn btn-sm btn-brand">Save</button>
                    </form>
                    <a href="?delete=<?= $booking['id'] ?>" onclick="return confirm('Delete booking?')" class="btn btn-sm btn-outline-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$bookings): ?>
            <tr><td colspan="8" class="text-center text-secondary">No bookings found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php include '../includes/admin_footer.php'; ?>
