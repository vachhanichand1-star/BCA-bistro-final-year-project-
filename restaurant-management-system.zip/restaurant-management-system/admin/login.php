<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
$pageTitle = 'Admin Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && verify_password_with_plaintext_upgrade($password, $admin['password'], 'admin', $admin['id'], $pdo)) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        redirect('dashboard.php');
    }

    flash('error', 'Invalid admin credentials.');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="admin-bg">
<section class="min-vh-100 d-flex align-items-center">
    <div class="container">
        <div class="col-lg-4 mx-auto auth-card p-4">
            <h2 class="fw-bold mb-3">Admin Login</h2>
            <?php if ($msg = flash('error')): ?><div class="alert alert-danger"><?= e($msg) ?></div><?php endif; ?>
            <form method="post">
                <div class="mb-3"><label class="form-label">Username</label><input name="username" class="form-control" value="admin" required></div>
                <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" value="admin123" required></div>
                <button class="btn btn-brand w-100">Login</button>
            </form>
            <a href="../index.php" class="d-block mt-3">Back to website</a>
        </div>
    </div>
</section>
</body>
</html>
