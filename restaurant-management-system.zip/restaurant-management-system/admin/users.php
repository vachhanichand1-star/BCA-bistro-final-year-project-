<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'User Management';

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    flash('success', 'User deleted.');
    redirect('users.php');
}

$users = $pdo->query("SELECT users.*, COUNT(orders.id) AS total_orders FROM users LEFT JOIN orders ON orders.user_id = users.id GROUP BY users.id ORDER BY users.id DESC")->fetchAll();
include '../includes/admin_header.php';
?>
<h1 class="fw-bold mb-4">User Management</h1>
<div class="content-card p-3 table-responsive">
    <table class="table align-middle">
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Joined</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td><td><?= e($user['name']) ?></td><td><?= e($user['email']) ?></td><td><?= e($user['phone']) ?></td><td><?= $user['total_orders'] ?></td><td><?= e($user['created_at']) ?></td>
                <td><a href="?delete=<?= $user['id'] ?>" onclick="return confirm('Delete user and related data?')" class="btn btn-sm btn-outline-danger">Delete</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include '../includes/admin_footer.php'; ?>
