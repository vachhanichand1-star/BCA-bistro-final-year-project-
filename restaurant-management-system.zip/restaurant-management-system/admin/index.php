<?php
require_once '../config/helpers.php';

if (is_admin_logged_in()) {
    redirect('dashboard.php');
}

redirect('login.php');
?>
