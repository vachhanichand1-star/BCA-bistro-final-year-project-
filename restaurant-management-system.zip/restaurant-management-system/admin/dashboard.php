<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Admin Dashboard';

// ── KPI Stats ─────────────────────────────────────────────────────────────
$totalOrders   = $pdo->query("SELECT COUNT(*) AS c FROM orders")->fetch()['c'];
$totalUsers    = $pdo->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
$totalRevenue  = $pdo->query("SELECT COALESCE(SUM(total_amount),0) AS c FROM orders WHERE status != 'Cancelled'")->fetch()['c'];
$totalFoods    = $pdo->query("SELECT COUNT(*) AS c FROM food_items")->fetch()['c'];
$pendingBookings = $pdo->query("SELECT COUNT(*) AS c FROM table_bookings WHERE status = 'Pending'")->fetch()['c'];

// Today's revenue
$todaySales = $pdo->query("SELECT COALESCE(SUM(total_amount),0) AS c FROM orders WHERE DATE(created_at) = CURDATE() AND status != 'Cancelled'")->fetch()['c'];

// Today's order count
$todayOrders = $pdo->query("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at) = CURDATE()")->fetch()['c'];

// ── Chart 1: Sales Overview – last 7 days ─────────────────────────────────
// Build a full 7-day range (fills in 0 for missing days)
$salesRaw = $pdo->query(
    "SELECT DATE(created_at) AS day, SUM(total_amount) AS sales
     FROM orders
     WHERE status != 'Cancelled'
       AND created_at >= CURDATE() - INTERVAL 6 DAY
     GROUP BY DATE(created_at)
     ORDER BY day ASC"
)->fetchAll(PDO::FETCH_KEY_PAIR);   // ['2024-04-12' => 1500.00, ...]

$salesLabels = [];
$salesData   = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i days"));
    $salesLabels[] = date('D, d M', strtotime($day));   // e.g. "Mon, 12 Apr"
    $salesData[]   = round((float)($salesRaw[$day] ?? 0), 2);
}

// ── Chart 2: Top Selling Items – top 6 by quantity sold ───────────────────
$topItems = $pdo->query(
    "SELECT f.name, SUM(oi.quantity) AS qty_sold
     FROM order_items oi
     JOIN food_items f ON f.id = oi.food_id
     JOIN orders o ON o.id = oi.order_id
     WHERE o.status != 'Cancelled'
     GROUP BY oi.food_id, f.name
     ORDER BY qty_sold DESC
     LIMIT 6"
)->fetchAll();

$topLabels   = array_column($topItems, 'name');
$topQty      = array_map('intval', array_column($topItems, 'qty_sold'));

// ── Recent Orders & Bookings ───────────────────────────────────────────────
$recentOrders   = $pdo->query("SELECT o.*, u.name FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC LIMIT 8")->fetchAll();
$recentBookings = $pdo->query("SELECT b.*, u.name FROM table_bookings b JOIN users u ON u.id = b.user_id ORDER BY b.created_at DESC LIMIT 5")->fetchAll();

include '../includes/admin_header.php';
?>

<style>
/* ── Dashboard Chart Styles ─────────────────────────────── */
.kpi-card {
    background: #fff;
    border-radius: 16px;
    padding: 1.25rem 1.5rem;
    border: 1px solid #f0f0f0;
    box-shadow: 0 2px 12px rgba(0,0,0,0.05);
    transition: transform 0.18s, box-shadow 0.18s;
    position: relative;
    overflow: hidden;
}
.kpi-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.09);
}
.kpi-card::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0;
    width: 100%; height: 3px;
    background: var(--kpi-color, #e23744);
}
.kpi-icon {
    width: 48px; height: 48px;
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.35rem;
    background: var(--kpi-bg, rgba(226,55,68,0.1));
    color: var(--kpi-color, #e23744);
    margin-bottom: 0.85rem;
}
.kpi-label { font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: #aaa; margin-bottom: 0.2rem; }
.kpi-value { font-size: 1.6rem; font-weight: 800; color: #1a1a2e; line-height: 1.1; }
.kpi-sub   { font-size: 0.78rem; color: #aaa; margin-top: 0.25rem; }

.chart-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid #f0f0f0;
    box-shadow: 0 2px 12px rgba(0,0,0,0.05);
    padding: 1.5rem;
}
.chart-card-title {
    font-size: 1rem;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 0.25rem;
}
.chart-card-subtitle {
    font-size: 0.8rem;
    color: #aaa;
    margin-bottom: 1.25rem;
}
.today-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
    background: linear-gradient(135deg, #e23744, #c11f2c);
    color: #fff;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: .05em;
    text-transform: uppercase;
    padding: 0.25rem 0.65rem;
    border-radius: 20px;
}
</style>

<!-- ── Page Header ─────────────────────────────────────────────────── -->
<div class="content-card p-4 mb-4">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-3 align-items-md-center">
        <div>
            <span class="badge text-bg-light text-brand mb-2">Admin Overview</span>
            <h1 class="fw-bold mb-1">Dashboard</h1>
            <p class="text-secondary mb-0">Track orders, revenue, bookings and restaurant activity from one place.</p>
        </div>
        <div class="text-end">
            <div class="text-secondary small mb-1">Welcome, <?= e($_SESSION['admin_username']) ?></div>
            <span class="today-badge"><i class="bi bi-calendar-check"></i> <?= date('D, d M Y') ?></span>
        </div>
    </div>
</div>

<!-- ── KPI Stats Row ──────────────────────────────────────────────── -->
<div class="row g-3 mb-4">

    <!-- Today's Revenue -->
    <div class="col-sm-6 col-xl">
        <div class="kpi-card" style="--kpi-color:#e23744;--kpi-bg:rgba(226,55,68,0.08);">
            <div class="kpi-icon"><i class="bi bi-currency-rupee"></i></div>
            <div class="kpi-label">Today's Revenue</div>
            <div class="kpi-value"><?= money($todaySales) ?></div>
            <div class="kpi-sub"><?= $todayOrders ?> order<?= $todayOrders != 1 ? 's' : '' ?> today</div>
        </div>
    </div>

    <!-- Total Revenue -->
    <div class="col-sm-6 col-xl">
        <div class="kpi-card" style="--kpi-color:#7c3aed;--kpi-bg:rgba(124,58,237,0.08);">
            <div class="kpi-icon"><i class="bi bi-graph-up-arrow"></i></div>
            <div class="kpi-label">Total Revenue</div>
            <div class="kpi-value"><?= money($totalRevenue) ?></div>
            <div class="kpi-sub">All time (excl. cancelled)</div>
        </div>
    </div>

    <!-- Total Orders -->
    <div class="col-sm-6 col-xl">
        <div class="kpi-card" style="--kpi-color:#0ea5e9;--kpi-bg:rgba(14,165,233,0.08);">
            <div class="kpi-icon"><i class="bi bi-bag-check"></i></div>
            <div class="kpi-label">Total Orders</div>
            <div class="kpi-value"><?= $totalOrders ?></div>
            <div class="kpi-sub">Since launch</div>
        </div>
    </div>

    <!-- Users -->
    <div class="col-sm-6 col-xl">
        <div class="kpi-card" style="--kpi-color:#10b981;--kpi-bg:rgba(16,185,129,0.08);">
            <div class="kpi-icon"><i class="bi bi-people"></i></div>
            <div class="kpi-label">Registered Users</div>
            <div class="kpi-value"><?= $totalUsers ?></div>
            <div class="kpi-sub"><?= $totalFoods ?> food items on menu</div>
        </div>
    </div>

    <!-- Pending Bookings -->
    <div class="col-sm-6 col-xl">
        <div class="kpi-card" style="--kpi-color:#f59e0b;--kpi-bg:rgba(245,158,11,0.08);">
            <div class="kpi-icon"><i class="bi bi-calendar-event"></i></div>
            <div class="kpi-label">Pending Bookings</div>
            <div class="kpi-value"><?= $pendingBookings ?></div>
            <div class="kpi-sub"><a href="bookings.php" class="text-decoration-none" style="color:#f59e0b;">View all →</a></div>
        </div>
    </div>

</div>

<!-- ── Charts Row ─────────────────────────────────────────────────── -->
<div class="row g-4 mb-4">

    <!-- Chart 1: Sales Overview Line Chart -->
    <div class="col-lg-7">
        <div class="chart-card h-100">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="chart-card-title"><i class="bi bi-bar-chart-line-fill me-1 text-danger"></i> Sales Overview</div>
                    <div class="chart-card-subtitle">Daily revenue for the last 7 days</div>
                </div>
                <span class="badge text-bg-light text-secondary">Last 7 Days</span>
            </div>
            <canvas id="salesChart" height="110"></canvas>
        </div>
    </div>

    <!-- Chart 2: Top Selling Items Bar Chart -->
    <div class="col-lg-5">
        <div class="chart-card h-100">
            <div>
                <div class="chart-card-title"><i class="bi bi-trophy-fill me-1 text-warning"></i> Top Selling Items</div>
                <div class="chart-card-subtitle">By total quantity sold (excl. cancelled orders)</div>
            </div>
            <?php if ($topItems): ?>
                <canvas id="topItemsChart" height="185"></canvas>
            <?php else: ?>
                <div class="text-center text-secondary py-5">
                    <i class="bi bi-inbox display-4"></i>
                    <p class="mt-2">No sales data yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<!-- ── Tables Row ─────────────────────────────────────────────────── -->
<div class="row g-4">

    <!-- Recent Orders Table -->
    <div class="col-lg-7">
        <div class="content-card p-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0">Recent Orders</h4>
                <a href="orders.php" class="btn btn-sm btn-outline-dark">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Payment</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td><span class="fw-bold">#<?= $order['id'] ?></span></td>
                            <td><?= e($order['name']) ?></td>
                            <td><?= money($order['total_amount']) ?></td>
                            <td>
                                <span class="badge text-bg-<?= $order['payment_status'] === 'Paid' ? 'success' : ($order['payment_status'] === 'Failed' ? 'danger' : 'warning') ?> text-bg-opacity-75">
                                    <?= e($order['payment_status']) ?>
                                </span>
                            </td>
                            <td><?= order_status_badge($order['status']) ?></td>
                            <td class="text-secondary" style="font-size:.82rem;"><?= date('d M, H:i', strtotime($order['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Recent Bookings + Quick Links -->
    <div class="col-lg-5">
        <div class="content-card p-3 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0">Recent Bookings</h4>
                <a href="bookings.php" class="btn btn-sm btn-outline-dark">View All</a>
            </div>
            <?php foreach ($recentBookings as $b): ?>
                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                    <div>
                        <div class="fw-semibold"><?= e($b['name']) ?></div>
                        <small class="text-secondary">
                            <?= date('d M', strtotime($b['booking_date'])) ?>
                            at <?= substr($b['booking_time'], 0, 5) ?>
                            &bull; <?= $b['guests'] ?> guests
                        </small>
                    </div>
                    <span class="badge text-bg-<?= $b['status'] === 'Confirmed' ? 'success' : ($b['status'] === 'Cancelled' ? 'danger' : 'warning') ?>">
                        <?= e($b['status']) ?>
                    </span>
                </div>
            <?php endforeach; ?>
            <?php if (!$recentBookings): ?>
                <p class="text-secondary text-center py-3 mb-0">No bookings yet.</p>
            <?php endif; ?>
        </div>

        <!-- Quick Links -->
        <div class="content-card p-3">
            <h5 class="fw-bold mb-3">Quick Actions</h5>
            <div class="d-grid gap-2">
                <a href="orders.php"     class="btn btn-outline-dark btn-sm text-start"><i class="bi bi-bag me-2"></i>Manage Orders</a>
                <a href="foods.php"      class="btn btn-outline-dark btn-sm text-start"><i class="bi bi-egg-fried me-2"></i>Manage Food Items</a>
                <a href="coupons.php"    class="btn btn-outline-dark btn-sm text-start"><i class="bi bi-tag me-2"></i>Manage Coupons</a>
                <a href="reports.php"    class="btn btn-outline-dark btn-sm text-start"><i class="bi bi-file-earmark-bar-graph me-2"></i>View Reports</a>
                <a href="settings.php"   class="btn btn-outline-dark btn-sm text-start"><i class="bi bi-gear me-2"></i>Settings</a>
            </div>
        </div>
    </div>

</div>

<!-- ── Chart.js Scripts ──────────────────────────────────────────── -->
<script>
// Pass PHP data to JavaScript
const salesLabels = <?= json_encode($salesLabels) ?>;
const salesData   = <?= json_encode($salesData) ?>;
const topLabels   = <?= json_encode($topLabels) ?>;
const topQty      = <?= json_encode($topQty) ?>;

document.addEventListener('DOMContentLoaded', function () {

    // ── Chart 1: Sales Overview (Line) ────────────────────────
    const salesCtx = document.getElementById('salesChart');
    if (salesCtx) {
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: salesLabels,
                datasets: [{
                    label: 'Revenue (Rs.)',
                    data: salesData,
                    borderColor: '#e23744',
                    backgroundColor: 'rgba(226, 55, 68, 0.08)',
                    borderWidth: 2.5,
                    pointBackgroundColor: '#e23744',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    fill: true,
                    tension: 0.4,   // smooth curve
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1a1a2e',
                        titleColor: '#aaa',
                        bodyColor: '#fff',
                        padding: 12,
                        callbacks: {
                            // Show "Rs. 1,250.00" in tooltip
                            label: ctx => ' Rs. ' + ctx.parsed.y.toLocaleString('en-IN', { minimumFractionDigits: 2 })
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#aaa', font: { size: 11 } }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(0,0,0,0.05)' },
                        ticks: {
                            color: '#aaa',
                            font: { size: 11 },
                            callback: val => 'Rs. ' + val.toLocaleString('en-IN')
                        }
                    }
                }
            }
        });
    }

    // ── Chart 2: Top Selling Items (Horizontal Bar) ───────────
    const topCtx = document.getElementById('topItemsChart');
    if (topCtx && topLabels.length > 0) {
        // Color palette for bars
        const barColors = [
            'rgba(226,55,68,0.82)',
            'rgba(124,58,237,0.82)',
            'rgba(14,165,233,0.82)',
            'rgba(16,185,129,0.82)',
            'rgba(245,158,11,0.82)',
            'rgba(236,72,153,0.82)',
        ];

        new Chart(topCtx, {
            type: 'bar',
            data: {
                labels: topLabels,
                datasets: [{
                    label: 'Units Sold',
                    data: topQty,
                    backgroundColor: barColors.slice(0, topLabels.length),
                    borderRadius: 8,
                    borderSkipped: false,
                    barThickness: 28,
                }]
            },
            options: {
                indexAxis: 'y',     // horizontal bar chart
                responsive: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1a1a2e',
                        titleColor: '#aaa',
                        bodyColor: '#fff',
                        padding: 12,
                        callbacks: {
                            label: ctx => '  ' + ctx.parsed.x + ' units sold'
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: { color: 'rgba(0,0,0,0.05)' },
                        ticks: { color: '#aaa', font: { size: 11 }, stepSize: 1 }
                    },
                    y: {
                        grid: { display: false },
                        ticks: {
                            color: '#333',
                            font: { size: 12, weight: '600' },
                            // Trim long food names
                            callback: function(val) {
                                const label = this.getLabelForValue(val);
                                return label.length > 18 ? label.slice(0, 17) + '…' : label;
                            }
                        }
                    }
                }
            }
        });
    }

});
</script>

<?php include '../includes/admin_footer.php'; ?>
