<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Website Settings';

$keys = [
    'restaurant_name' => 'Restaurant Name',
    'restaurant_phone' => 'Phone Number',
    'restaurant_address' => 'Address',
    'upi_id' => 'UPI ID',
    'gst_percent' => 'GST Percentage',
    'delivery_charge' => 'Delivery Charge',
    'free_delivery_above' => 'Free Delivery Above',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    foreach ($keys as $key => $label) {
        $stmt->execute([$key, trim($_POST[$key] ?? '')]);
    }
    flash('success', 'Settings updated.');
    redirect('settings.php');
}

$settings = [];
foreach ($keys as $key => $label) {
    $settings[$key] = get_setting($pdo, $key, '');
}
include '../includes/admin_header.php';
?>
<h1 class="fw-bold mb-4">Website Settings</h1>
<div class="col-xl-7">
    <div class="content-card p-4">
        <form method="post">
            <?php foreach ($keys as $key => $label): ?>
                <div class="mb-3">
                    <label class="form-label"><?= e($label) ?></label>
                    <input name="<?= e($key) ?>" class="form-control" value="<?= e($settings[$key]) ?>" required>
                </div>
            <?php endforeach; ?>
            <button class="btn btn-brand">Save Settings</button>
        </form>
    </div>
</div>
<?php include '../includes/admin_footer.php'; ?>
