<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Order Management';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], (int) $_POST['order_id']]);
    flash('success', 'Order status updated.');
    redirect('orders.php');
}

$status = $_GET['status'] ?? '';
$sql = "SELECT o.*, u.name, u.phone FROM orders o JOIN users u ON u.id = o.user_id";
$params = [];
if ($status) {
    $sql .= " WHERE o.status = ?";
    $params[] = $status;
}
$sql .= " ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();
include '../includes/admin_header.php';
?>
<div class="content-card p-4 mb-4">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-3 align-items-md-center">
    <div>
        <span class="badge text-bg-light text-brand mb-2">Admin Control</span>
        <h1 class="fw-bold mb-1">Order Management</h1>
        <p class="text-secondary mb-0">Update live order status and verify payment details.</p>
    </div>
    <form class="d-flex gap-2">
        <select name="status" class="form-select">
            <option value="">All Orders</option>
            <?php foreach (['Pending','Preparing','Out for Delivery','Delivered','Cancelled'] as $option): ?>
                <option <?= $status === $option ? 'selected' : '' ?>><?= $option ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-brand">Filter</button>
    </form>
    </div>
</div>
<div class="content-card p-3 table-responsive">
    <table class="table align-middle">
        <thead><tr><th>ID</th><th>User</th><th>Phone</th><th>Total</th><th>Payment</th><th>Order Status</th><th>Items</th><th>Update</th></tr></thead>
        <tbody>
        <?php foreach ($orders as $order): ?>
            <?php
            $itemStmt = $pdo->prepare("SELECT oi.*, f.name FROM order_items oi JOIN food_items f ON f.id = oi.food_id WHERE oi.order_id = ?");
            $itemStmt->execute([$order['id']]);
            $items = $itemStmt->fetchAll();
            ?>
            <tr>
                <td>#<?= $order['id'] ?></td>
                <td><?= e($order['name']) ?></td>
                <td><?= e($order['phone']) ?></td>
                <td><?= money($order['total_amount']) ?></td>
                <td>
                    <?= e($order['payment_method']) ?><br>
                    <small class="text-secondary"><?= e($order['payment_status']) ?><?= $order['transaction_id'] ? ' | ' . e($order['transaction_id']) : '' ?></small>
                </td>
                <td><?= order_status_badge($order['status']) ?></td>
                <td>
                    <?php foreach ($items as $item): ?>
                        <div><?= e($item['name']) ?> x <?= $item['quantity'] ?></div>
                    <?php endforeach; ?>
                </td>
                <td>
                    <form method="post" class="d-flex gap-2">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <select name="status" class="form-select form-select-sm">
                            <?php foreach (['Pending','Preparing','Out for Delivery','Delivered','Cancelled'] as $option): ?>
                                <option <?= $order['status'] === $option ? 'selected' : '' ?>><?= $option ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn btn-sm btn-brand">Save</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include '../includes/admin_footer.php'; ?>
