<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Sales Reports';

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

$dailyStmt = $pdo->prepare("SELECT DATE(created_at) AS period, COUNT(*) AS orders, SUM(total_amount) AS sales FROM orders WHERE status != 'Cancelled' AND DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY period DESC");
$dailyStmt->execute([$from, $to]);
$dailyReports = $dailyStmt->fetchAll();

$monthlyReports = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') AS period, COUNT(*) AS orders, SUM(total_amount) AS sales FROM orders WHERE status != 'Cancelled' GROUP BY DATE_FORMAT(created_at, '%Y-%m') ORDER BY period DESC")->fetchAll();
include '../includes/admin_header.php';
?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-3 mb-4">
    <h1 class="fw-bold">Sales Reports</h1>
    <form class="d-flex gap-2">
        <input type="date" name="from" value="<?= e($from) ?>" class="form-control">
        <input type="date" name="to" value="<?= e($to) ?>" class="form-control">
        <button class="btn btn-brand">Apply</button>
    </form>
</div>
<div class="row g-4">
    <div class="col-lg-6">
        <div class="content-card p-3">
            <h4 class="fw-bold">Daily Sales</h4>
            <table class="table align-middle">
                <thead><tr><th>Date</th><th>Orders</th><th>Sales</th></tr></thead>
                <tbody><?php foreach ($dailyReports as $row): ?><tr><td><?= e($row['period']) ?></td><td><?= $row['orders'] ?></td><td><?= money($row['sales']) ?></td></tr><?php endforeach; ?></tbody>
            </table>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="content-card p-3">
            <h4 class="fw-bold">Monthly Sales</h4>
            <table class="table align-middle">
                <thead><tr><th>Month</th><th>Orders</th><th>Sales</th></tr></thead>
                <tbody><?php foreach ($monthlyReports as $row): ?><tr><td><?= e($row['period']) ?></td><td><?= $row['orders'] ?></td><td><?= money($row['sales']) ?></td></tr><?php endforeach; ?></tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/admin_footer.php'; ?>
