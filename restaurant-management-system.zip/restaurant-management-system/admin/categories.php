<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Category Management';

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    flash('success', 'Category deleted.');
    redirect('categories.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $status = $_POST['status'];
    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE categories SET name = ?, status = ? WHERE id = ?");
        $stmt->execute([$name, $status, (int) $_POST['id']]);
        flash('success', 'Category updated.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO categories (name, status) VALUES (?, ?)");
        $stmt->execute([$name, $status]);
        flash('success', 'Category added.');
    }
    redirect('categories.php');
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
include '../includes/admin_header.php';
?>
<h1 class="fw-bold mb-4">Category Management</h1>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="content-card p-3">
            <h4 class="fw-bold"><?= $edit ? 'Edit' : 'Add' ?> Category</h4>
            <form method="post">
                <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
                <div class="mb-3"><label class="form-label">Name</label><input name="name" class="form-control" value="<?= e($edit['name'] ?? '') ?>" required></div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option <?= ($edit['status'] ?? '') === 'Active' ? 'selected' : '' ?>>Active</option>
                        <option <?= ($edit['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <button class="btn btn-brand"><?= $edit ? 'Update' : 'Add' ?></button>
                <?php if ($edit): ?><a href="categories.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="content-card p-3 table-responsive">
            <table class="table align-middle">
                <thead><tr><th>ID</th><th>Name</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= $category['id'] ?></td><td><?= e($category['name']) ?></td><td><?= e($category['status']) ?></td>
                        <td>
                            <a href="?edit=<?= $category['id'] ?>" class="btn btn-sm btn-outline-dark">Edit</a>
                            <a href="?delete=<?= $category['id'] ?>" onclick="return confirm('Delete category?')" class="btn btn-sm btn-outline-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/admin_footer.php'; ?>
