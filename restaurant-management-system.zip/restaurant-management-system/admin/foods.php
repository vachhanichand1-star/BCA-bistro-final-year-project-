<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Food Management';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM food_items WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM food_items WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    flash('success', 'Food item deleted.');
    redirect('foods.php');
}

function upload_food_image($oldImage = null)
{
    if (empty($_FILES['image']['name'])) return $oldImage;

    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return $oldImage;

    $fileName = uniqid('food_', true) . '.' . $ext;
    move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/food/' . $fileName);
    return $fileName;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $image = upload_food_image($_POST['old_image'] ?? null);
    $data = [$_POST['category_id'], trim($_POST['name']), trim($_POST['description']), $_POST['price'], $image, $_POST['rating'], $_POST['status']];
    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE food_items SET category_id = ?, name = ?, description = ?, price = ?, image = ?, rating = ?, status = ? WHERE id = ?");
        $data[] = (int) $_POST['id'];
        $stmt->execute($data);
        flash('success', 'Food item updated.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO food_items (category_id, name, description, price, image, rating, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute($data);
        flash('success', 'Food item added.');
    }
    redirect('foods.php');
}

$foods = $pdo->query("SELECT f.*, c.name AS category_name FROM food_items f JOIN categories c ON c.id = f.category_id ORDER BY f.id DESC")->fetchAll();
include '../includes/admin_header.php';
?>
<h1 class="fw-bold mb-4">Food Management</h1>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="content-card p-3">
            <h4 class="fw-bold"><?= $edit ? 'Edit' : 'Add' ?> Food</h4>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
                <input type="hidden" name="old_image" value="<?= e($edit['image'] ?? '') ?>">
                <div class="mb-3"><label class="form-label">Category</label><select name="category_id" class="form-select" required><?php foreach ($categories as $cat): ?><option value="<?= $cat['id'] ?>" <?= ($edit['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option><?php endforeach; ?></select></div>
                <div class="mb-3"><label class="form-label">Name</label><input name="name" class="form-control" value="<?= e($edit['name'] ?? '') ?>" required></div>
                <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"><?= e($edit['description'] ?? '') ?></textarea></div>
                <div class="mb-3"><label class="form-label">Price</label><input type="number" step="0.01" name="price" class="form-control" value="<?= e($edit['price'] ?? '') ?>" required></div>
                <div class="mb-3"><label class="form-label">Rating</label><input type="number" step="0.1" min="1" max="5" name="rating" class="form-control" value="<?= e($edit['rating'] ?? '4.5') ?>"></div>
                <div class="mb-3"><label class="form-label">Image</label><input type="file" name="image" class="form-control"></div>
                <div class="mb-3"><label class="form-label">Status</label><select name="status" class="form-select"><option <?= ($edit['status'] ?? '') === 'Available' ? 'selected' : '' ?>>Available</option><option <?= ($edit['status'] ?? '') === 'Unavailable' ? 'selected' : '' ?>>Unavailable</option></select></div>
                <button class="btn btn-brand"><?= $edit ? 'Update' : 'Add' ?></button>
                <?php if ($edit): ?><a href="foods.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="content-card p-3 table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php foreach ($foods as $food): ?>
                    <tr>
                        <?php $img = food_image($food['image']); $img = (strpos($img, 'http') === 0) ? $img : '../' . $img; ?>
                        <td><img src="<?= e($img) ?>" alt=""></td><td><?= e($food['name']) ?></td><td><?= e($food['category_name']) ?></td><td><?= money($food['price']) ?></td><td><?= e($food['status']) ?></td>
                        <td><a href="?edit=<?= $food['id'] ?>" class="btn btn-sm btn-outline-dark">Edit</a> <a href="?delete=<?= $food['id'] ?>" onclick="return confirm('Delete food item?')" class="btn btn-sm btn-outline-danger">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/admin_footer.php'; ?>
