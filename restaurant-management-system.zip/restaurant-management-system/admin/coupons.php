<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
require_admin();
$pageTitle = 'Coupon Management';

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM coupons WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM coupons WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    flash('success', 'Coupon deleted.');
    redirect('coupons.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = strtoupper(trim($_POST['code']));
    $discount = (int) $_POST['discount_percent'];
    $minAmount = (float) $_POST['min_order_amount'];
    $expiry = $_POST['expiry_date'] ?: null;
    $status = $_POST['status'];

    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE coupons SET code = ?, discount_percent = ?, min_order_amount = ?, expiry_date = ?, status = ? WHERE id = ?");
        $stmt->execute([$code, $discount, $minAmount, $expiry, $status, (int) $_POST['id']]);
        flash('success', 'Coupon updated.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO coupons (code, discount_percent, min_order_amount, expiry_date, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$code, $discount, $minAmount, $expiry, $status]);
        flash('success', 'Coupon added.');
    }
    redirect('coupons.php');
}

$coupons = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
include '../includes/admin_header.php';
?>
<h1 class="fw-bold mb-4">Coupon Management</h1>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="content-card p-3">
            <h4 class="fw-bold"><?= $edit ? 'Edit' : 'Add' ?> Coupon</h4>
            <form method="post">
                <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
                <div class="mb-3"><label class="form-label">Coupon Code</label><input name="code" class="form-control" value="<?= e($edit['code'] ?? '') ?>" required></div>
                <div class="mb-3"><label class="form-label">Discount %</label><input type="number" min="1" max="90" name="discount_percent" class="form-control" value="<?= e($edit['discount_percent'] ?? '') ?>" required></div>
                <div class="mb-3"><label class="form-label">Minimum Order</label><input type="number" step="0.01" name="min_order_amount" class="form-control" value="<?= e($edit['min_order_amount'] ?? '0') ?>"></div>
                <div class="mb-3"><label class="form-label">Expiry Date</label><input type="date" name="expiry_date" class="form-control" value="<?= e($edit['expiry_date'] ?? '') ?>"></div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option <?= ($edit['status'] ?? '') === 'Active' ? 'selected' : '' ?>>Active</option>
                        <option <?= ($edit['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <button class="btn btn-brand"><?= $edit ? 'Update' : 'Add' ?></button>
                <?php if ($edit): ?><a href="coupons.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="content-card p-3 table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Code</th><th>Discount</th><th>Minimum</th><th>Expiry</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php foreach ($coupons as $coupon): ?>
                    <tr>
                        <td><strong><?= e($coupon['code']) ?></strong></td>
                        <td><?= e($coupon['discount_percent']) ?>%</td>
                        <td><?= money($coupon['min_order_amount']) ?></td>
                        <td><?= e($coupon['expiry_date'] ?: 'No expiry') ?></td>
                        <td><?= e($coupon['status']) ?></td>
                        <td>
                            <a href="?edit=<?= $coupon['id'] ?>" class="btn btn-sm btn-outline-dark">Edit</a>
                            <a href="?delete=<?= $coupon['id'] ?>" onclick="return confirm('Delete coupon?')" class="btn btn-sm btn-outline-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/admin_footer.php'; ?>
