<?php
require_once '../config/database.php';
require_once '../config/helpers.php';
header('Content-Type: application/json');

if (!is_user_logged_in()) {
    echo json_encode(['success' => false]);
    exit;
}

$orderId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT status FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

echo json_encode([
    'success' => (bool) $order,
    'status' => $order['status'] ?? '',
]);
?>
