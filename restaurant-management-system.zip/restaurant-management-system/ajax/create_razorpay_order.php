<?php
// ============================================================
// ajax/create_razorpay_order.php
// ============================================================
// Called via AJAX from checkout.php when user selects Razorpay.
//
// What this file does:
//   1. Reads cart items from database
//   2. Calculates the final total (with GST, delivery, coupon)
//   3. Creates an order row in the 'orders' table (status = Pending)
//   4. Calls the Razorpay API to get a Razorpay Order ID
//   5. Saves details in the 'payments' table
//   6. Returns JSON data to JavaScript so it can open the payment popup
// ============================================================

require_once '../config/database.php';
require_once '../config/helpers.php';
require_once '../config/razorpay.php';

// Always return JSON
header('Content-Type: application/json');

// --- Security Checks ---
if (!is_user_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Please log in to continue.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

// --- Read Form Data ---
$address    = trim($_POST['address'] ?? '');
$couponCode = strtoupper(trim($_POST['coupon_code'] ?? ''));

if (!$address) {
    echo json_encode(['success' => false, 'message' => 'Delivery address is required.']);
    exit;
}

// --- Load Cart Items ---
$stmt = $pdo->prepare(
    "SELECT cart.*, f.name, f.price
     FROM cart
     JOIN food_items f ON f.id = cart.food_id
     WHERE cart.user_id = ?"
);
$stmt->execute([$_SESSION['user_id']]);
$cartItems = $stmt->fetchAll();

if (!$cartItems) {
    echo json_encode(['success' => false, 'message' => 'Your cart is empty.']);
    exit;
}

// --- Calculate Total (same logic as checkout.php) ---
$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$gstPercent      = (float) get_setting($pdo, 'gst_percent', '5');
$deliveryCharge  = (float) get_setting($pdo, 'delivery_charge', '30');
$freeDeliveryAbove = (float) get_setting($pdo, 'free_delivery_above', '799');

$taxAmount      = $subtotal * ($gstPercent / 100);
$deliveryAmount = $subtotal >= $freeDeliveryAbove ? 0 : $deliveryCharge;
$discount       = 0;

// Apply coupon if provided
if ($couponCode) {
    $couponStmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND status = 'Active'");
    $couponStmt->execute([$couponCode]);
    $coupon = $couponStmt->fetch();

    if ($coupon
        && $subtotal >= (float) $coupon['min_order_amount']
        && (!$coupon['expiry_date'] || $coupon['expiry_date'] >= date('Y-m-d'))
    ) {
        $discount = $subtotal * ($coupon['discount_percent'] / 100);
    }
}

$total = max(0, $subtotal + $taxAmount + $deliveryAmount - $discount);

// Razorpay requires the amount in PAISE (1 INR = 100 paise)
$amountPaise = (int) round($total * 100);

// Razorpay minimum is 100 paise (Rs. 1)
if ($amountPaise < 100) {
    echo json_encode(['success' => false, 'message' => 'Order amount is too small for online payment.']);
    exit;
}

// --- Load User Details (for Razorpay prefill) ---
$userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([$_SESSION['user_id']]);
$user = $userStmt->fetch();

// --- Create Order in DB & Call Razorpay API ---
try {
    $pdo->beginTransaction();

    // Insert the order row (payment_status = Pending until payment is verified)
    $orderStmt = $pdo->prepare(
        "INSERT INTO orders
            (user_id, subtotal, tax_amount, delivery_charge, total_amount,
             payment_method, payment_status, delivery_address, coupon_code, discount_amount)
         VALUES (?, ?, ?, ?, ?, 'Razorpay', 'Pending', ?, ?, ?)"
    );
    $orderStmt->execute([
        $_SESSION['user_id'], $subtotal, $taxAmount, $deliveryAmount,
        $total, $address, $couponCode ?: null, $discount
    ]);
    $orderId = $pdo->lastInsertId();

    // Save order items
    $itemStmt = $pdo->prepare(
        "INSERT INTO order_items (order_id, food_id, quantity, price) VALUES (?, ?, ?, ?)"
    );
    foreach ($cartItems as $item) {
        $itemStmt->execute([$orderId, $item['food_id'], $item['quantity'], $item['price']]);
    }

    // Call Razorpay API to create a Razorpay Order
    $razorpayOrder = callRazorpayCreateOrder($amountPaise, 'receipt_order_' . $orderId);

    if (!isset($razorpayOrder['id'])) {
        // API call failed
        $errMsg = $razorpayOrder['error']['description'] ?? 'Razorpay API error. Check your API keys.';
        throw new Exception($errMsg);
    }

    $razorpayOrderId = $razorpayOrder['id'];

    // Save Razorpay Order ID in the orders table
    $pdo->prepare("UPDATE orders SET razorpay_order_id = ? WHERE id = ?")
        ->execute([$razorpayOrderId, $orderId]);

    // Insert a row in the payments table (status = 'created')
    $payStmt = $pdo->prepare(
        "INSERT INTO payments (order_id, razorpay_order_id, amount, currency, status)
         VALUES (?, ?, ?, 'INR', 'created')"
    );
    $payStmt->execute([$orderId, $razorpayOrderId, $total]);

    $pdo->commit();

    // Return data to JavaScript so it can open the Razorpay popup
    echo json_encode([
        'success'          => true,
        'razorpay_order_id'=> $razorpayOrderId,
        'amount'           => $amountPaise,          // in paise
        'key_id'           => RAZORPAY_KEY_ID,
        'order_id'         => $orderId,              // our internal DB order ID
        'name'             => $user['name'],
        'email'            => $user['email'],
        'phone'            => $user['phone'] ?? '',
        'total_display'    => money($total),
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

// ============================================================
// Helper: Call Razorpay API to create an order
// Uses PHP's cURL – no Composer/SDK needed
// ============================================================
function callRazorpayCreateOrder($amountPaise, $receipt)
{
    $payload = json_encode([
        'amount'   => $amountPaise,
        'currency' => RAZORPAY_CURRENCY,
        'receipt'  => $receipt,
    ]);

    $ch = curl_init('https://api.razorpay.com/v1/orders');
    curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $curlError = curl_errno($ch);
    curl_close($ch);

    if ($curlError) {
        return ['error' => ['description' => 'Network error connecting to Razorpay. Check internet/cURL.']];
    }

    return json_decode($response, true);
}
