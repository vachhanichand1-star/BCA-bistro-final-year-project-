<?php
require_once '../config/database.php';
require_once '../config/helpers.php';

header('Content-Type: application/json');
$action = $_GET['action'] ?? '';

if (!is_user_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Please login first.', 'count' => 0]);
    exit;
}

$userId = $_SESSION['user_id'];

if ($action === 'count') {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity), 0) AS total FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    echo json_encode(['success' => true, 'count' => (int) $stmt->fetch()['total']]);
    exit;
}

if ($action === 'add') {
    $foodId = (int) ($_POST['food_id'] ?? 0);
    $stmt = $pdo->prepare("INSERT INTO cart (user_id, food_id, quantity) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1");
    $stmt->execute([$userId, $foodId]);
    echo json_encode(['success' => true, 'message' => 'Item added to cart.']);
    exit;
}

if ($action === 'update') {
    $cartId = (int) ($_POST['cart_id'] ?? 0);
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
    $stmt->execute([$quantity, $cartId, $userId]);
    echo json_encode(['success' => true, 'message' => 'Cart updated.']);
    exit;
}

if ($action === 'remove') {
    $cartId = (int) ($_POST['cart_id'] ?? 0);
    $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cartId, $userId]);
    echo json_encode(['success' => true, 'message' => 'Item removed.']);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action.']);
?>
