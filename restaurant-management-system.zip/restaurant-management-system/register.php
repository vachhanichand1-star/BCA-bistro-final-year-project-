<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
$pageTitle = 'Register';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = $_POST['password'];

    if ($name && $email && $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, phone, address) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hash, $phone, $address]);
            flash('success', 'Registration successful. Please login.');
            redirect('login.php');
        } catch (PDOException $e) {
            flash('error', 'Email already registered.');
        }
    } else {
        flash('error', 'Please fill all required fields.');
    }
}
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container">
        <div class="col-lg-6 mx-auto auth-card p-4">
            <h2 class="fw-bold mb-3">Create Account</h2>
            <form method="post">
                <div class="mb-3"><label class="form-label">Name</label><input name="name" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Phone</label><input name="phone" class="form-control"></div>
                <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="3"></textarea></div>
                <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
                <button class="btn btn-brand w-100">Register</button>
            </form>
            <p class="mt-3 mb-0">Already registered? <a href="login.php">Login</a></p>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
