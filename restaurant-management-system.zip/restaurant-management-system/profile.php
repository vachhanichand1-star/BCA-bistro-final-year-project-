<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Profile';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->execute([trim($_POST['name']), trim($_POST['phone']), trim($_POST['address']), $_SESSION['user_id']]);
    $_SESSION['user_name'] = trim($_POST['name']);
    flash('success', 'Profile updated.');
    redirect('profile.php');
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
$bookingStmt = $pdo->prepare("SELECT * FROM table_bookings WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$bookingStmt->execute([$_SESSION['user_id']]);
$bookings = $bookingStmt->fetchAll();
include 'includes/header.php';
?>
<section class="py-5 section-band"><div class="container"><h1 class="fw-bold">Profile</h1></div></section>
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="content-card p-4">
                    <form method="post">
                        <div class="mb-3"><label class="form-label">Name</label><input name="name" class="form-control" value="<?= e($user['name']) ?>" required></div>
                        <div class="mb-3"><label class="form-label">Email</label><input class="form-control" value="<?= e($user['email']) ?>" disabled></div>
                        <div class="mb-3"><label class="form-label">Phone</label><input name="phone" class="form-control" value="<?= e($user['phone']) ?>"></div>
                        <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="3"><?= e($user['address']) ?></textarea></div>
                        <button class="btn btn-brand">Update Profile</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="content-card p-4">
                    <h4 class="fw-bold">Book a Table</h4>
                    <form method="post" action="book_table.php" class="row g-2">
                        <div class="col-6"><input type="date" name="booking_date" class="form-control" required></div>
                        <div class="col-6"><input type="time" name="booking_time" class="form-control" required></div>
                        <div class="col-12"><input type="number" min="1" name="guests" class="form-control" placeholder="Guests" required></div>
                        <div class="col-12"><button class="btn btn-brand w-100">Request Booking</button></div>
                    </form>
                    <h6 class="fw-bold mt-4">Recent Bookings</h6>
                    <?php foreach ($bookings as $booking): ?>
                        <div class="border-bottom py-2 small"><?= e($booking['booking_date']) ?> at <?= e($booking['booking_time']) ?>, <?= e($booking['guests']) ?> guests - <?= e($booking['status']) ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
