<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO table_bookings (user_id, booking_date, booking_time, guests) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $_POST['booking_date'], $_POST['booking_time'], (int) $_POST['guests']]);
    flash('success', 'Table booking request submitted.');
    redirect('profile.php');
}
?>
