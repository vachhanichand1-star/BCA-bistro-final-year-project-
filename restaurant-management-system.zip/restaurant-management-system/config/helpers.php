<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header("Location: $path");
    exit;
}

function is_user_logged_in()
{
    return isset($_SESSION['user_id']);
}

function is_admin_logged_in()
{
    return isset($_SESSION['admin_id']);
}

function require_user()
{
    if (!is_user_logged_in()) {
        redirect('login.php');
    }
}

function require_admin()
{
    if (!is_admin_logged_in()) {
        redirect('login.php');
    }
}

function flash($key, $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }

    if (!empty($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }

    return null;
}

function verify_password_with_plaintext_upgrade($inputPassword, $storedPassword, $table, $id, $pdo)
{
    if (password_verify($inputPassword, $storedPassword)) {
        return true;
    }

    // This allows sample SQL passwords like admin123/user123 to work on first login.
    // After the first successful login, the password is replaced with a secure hash.
    if (hash_equals($storedPassword, $inputPassword)) {
        $hash = password_hash($inputPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE $table SET password = ? WHERE id = ?");
        $stmt->execute([$hash, $id]);
        return true;
    }

    return false;
}

function money($amount)
{
    return 'Rs. ' . number_format((float) $amount, 2);
}

function get_setting($pdo, $key, $default = '')
{
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['setting_value'] : $default;
}

function food_image($image)
{
    if (!$image) {
        return 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=900&q=80';
    }

    if (strpos($image, 'http://') === 0 || strpos($image, 'https://') === 0) {
        return $image;
    }

    return 'uploads/food/' . $image;
}

function order_status_badge($status)
{
    $classes = [
        'Pending' => 'warning',
        'Preparing' => 'info',
        'Out for Delivery' => 'primary',
        'Delivered' => 'success',
        'Cancelled' => 'danger',
    ];

    $class = $classes[$status] ?? 'secondary';
    return '<span class="badge text-bg-' . $class . '">' . e($status) . '</span>';
}
?>
