<?php
// ============================================================
// Razorpay API Configuration
// ============================================================
// HOW TO GET YOUR KEYS:
//   1. Sign up free at https://razorpay.com
//   2. Go to: Dashboard → Settings → API Keys
//   3. Click "Generate Test Key"
//   4. Copy the Key ID and Key Secret and paste below
//
// NOTE: Keys starting with "rzp_test_" are TEST keys.
//       No real money is charged in test mode.
// ============================================================

define('RAZORPAY_KEY_ID',     'rzp_test_Seh4ytiaUEilrn');  // Replace with your Key ID
define('RAZORPAY_KEY_SECRET', 'OLi7G2SB2OJrkXxbF7aMnEL4');   // Replace with your Key Secret
define('RAZORPAY_CURRENCY',   'INR');
