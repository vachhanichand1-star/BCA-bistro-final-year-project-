<?php
// Database configuration for XAMPP.
// Update these values if your MySQL username/password is different.
$host = 'localhost';
$db_name = 'restaurant_management';
$username = 'root';
$password = '';

try {
    // Connect to MySQL first, create the database if it is missing, then select it.
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$db_name`");

    // If project tables are missing, show a friendly setup page instead of a fatal error.
    $currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($currentScript !== 'setup_database.php') {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = 'food_items'");
        $stmt->execute([$db_name]);
        if ((int) $stmt->fetchColumn() === 0) {
            header('Location: setup_database.php');
            exit;
        }
    }
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}
?>
