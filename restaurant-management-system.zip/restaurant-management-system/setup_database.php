<?php
require_once 'config/database.php';
require_once 'config/helpers.php';

$pageTitle = 'Database Setup';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sqlFile = __DIR__ . '/database/restaurant_management.sql';

    if (!file_exists($sqlFile)) {
        $error = 'SQL file not found.';
    } else {
        try {
            $sql = file_get_contents($sqlFile);
            $pdo->exec($sql);
            $message = 'Database imported successfully. You can open the website now.';
        } catch (PDOException $e) {
            $error = 'Import failed: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="admin-bg">
<section class="min-vh-100 d-flex align-items-center">
    <div class="container">
        <div class="col-lg-6 mx-auto content-card p-4">
            <h1 class="fw-bold">Database Setup Required</h1>
            <p class="text-secondary">The database exists, but required tables are missing. Click the button below to import the project SQL file.</p>

            <?php if ($message): ?>
                <div class="alert alert-success"><?= e($message) ?></div>
                <a href="index.php" class="btn btn-brand">Open Website</a>
                <a href="admin/" class="btn btn-outline-dark">Open Admin Panel</a>
            <?php else: ?>
                <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
                <form method="post">
                    <button class="btn btn-brand">Import Database Now</button>
                </form>
                <hr>
                <p class="small text-secondary mb-0">
                    Manual option: open phpMyAdmin, drop the old <strong>restaurant_management</strong> database, then import
                    <strong>database/restaurant_management.sql</strong>.
                </p>
            <?php endif; ?>
        </div>
    </div>
</section>
</body>
</html>
