<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Review Order';

$orderId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ? AND status = 'Delivered'");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) {
    flash('error', 'You can review only delivered orders.');
    redirect('orders.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['rating'] as $foodId => $rating) {
        $foodId = (int) $foodId;
        $rating = max(1, min(5, (int) $rating));
        $comment = trim($_POST['comment'][$foodId] ?? '');
        $reviewStmt = $pdo->prepare("INSERT INTO reviews (user_id, food_id, order_id, rating, comment) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment)");
        $reviewStmt->execute([$_SESSION['user_id'], $foodId, $orderId, $rating, $comment]);
    }
    flash('success', 'Thanks for your review.');
    redirect('orders.php');
}

$itemsStmt = $pdo->prepare("SELECT oi.*, f.name, f.image FROM order_items oi JOIN food_items f ON f.id = oi.food_id WHERE oi.order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();
include 'includes/header.php';
?>
<section class="py-5 section-band"><div class="container"><h1 class="fw-bold">Review Order #<?= $orderId ?></h1></div></section>
<section class="py-5">
    <div class="container">
        <form method="post" class="content-card p-4">
            <?php foreach ($items as $item): ?>
                <div class="row g-3 align-items-center border-bottom py-3">
                    <div class="col-md-4">
                        <img src="<?= e(food_image($item['image'])) ?>" alt="<?= e($item['name']) ?>" class="rounded-2" style="width:90px;height:70px;object-fit:cover">
                        <strong class="ms-2"><?= e($item['name']) ?></strong>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Rating</label>
                        <select name="rating[<?= $item['food_id'] ?>]" class="form-select">
                            <option value="5">5 - Excellent</option>
                            <option value="4">4 - Good</option>
                            <option value="3">3 - Average</option>
                            <option value="2">2 - Poor</option>
                            <option value="1">1 - Bad</option>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Comment</label>
                        <input name="comment[<?= $item['food_id'] ?>]" class="form-control" placeholder="Share your experience">
                    </div>
                </div>
            <?php endforeach; ?>
            <button class="btn btn-brand mt-3">Submit Reviews</button>
        </form>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
