<?php
require_once 'config/helpers.php';
$pageTitle = 'Forgot Password';
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container">
        <div class="col-lg-5 mx-auto auth-card p-4">
            <h2 class="fw-bold mb-3">Forgot Password</h2>
            <p class="text-secondary">Email sending is optional in this project. For demo, contact admin to reset your password in the users table.</p>
            <a href="login.php" class="btn btn-brand">Back to Login</a>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
