<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Invoice';

$orderId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT o.*, u.name, u.email, u.phone FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) redirect('orders.php');

$itemsStmt = $pdo->prepare("SELECT oi.*, f.name FROM order_items oi JOIN food_items f ON f.id = oi.food_id WHERE oi.order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();
$restaurantName = get_setting($pdo, 'restaurant_name', 'BCA Bistro');
$restaurantPhone = get_setting($pdo, 'restaurant_phone', '+91 98765 43210');
$restaurantAddress = get_setting($pdo, 'restaurant_address', 'Surat, Gujarat');
include 'includes/header.php';
?>
<section class="py-5 section-band">
    <div class="container d-flex justify-content-between align-items-center">
        <h1 class="fw-bold">Invoice #<?= $order['id'] ?></h1>
        <button onclick="window.print()" class="btn btn-brand">Print Invoice</button>
    </div>
</section>
<section class="py-5">
    <div class="container">
        <div class="content-card p-4">
            <div class="d-flex flex-column flex-md-row justify-content-between gap-3 border-bottom pb-3 mb-3">
                <div>
                    <h3 class="fw-bold"><?= e($restaurantName) ?></h3>
                    <p class="mb-1"><?= e($restaurantAddress) ?></p>
                    <p class="mb-0"><?= e($restaurantPhone) ?></p>
                </div>
                <div class="text-md-end">
                    <p class="mb-1"><strong>Date:</strong> <?= e($order['created_at']) ?></p>
                    <p class="mb-1"><strong>Payment:</strong> <?= e($order['payment_method']) ?> (<?= e($order['payment_status']) ?>)</p>
                    <?php if ($order['transaction_id']): ?><p class="mb-0"><strong>Txn:</strong> <?= e($order['transaction_id']) ?></p><?php endif; ?>
                </div>
            </div>
            <div class="mb-3">
                <h5 class="fw-bold">Customer</h5>
                <p class="mb-1"><?= e($order['name']) ?> | <?= e($order['phone']) ?></p>
                <p class="mb-0"><?= e($order['delivery_address']) ?></p>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Food</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
                    <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= e($item['name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= money($item['price']) ?></td>
                            <td><?= money($item['price'] * $item['quantity']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-5 ms-auto">
                <div class="d-flex justify-content-between"><span>Subtotal</span><span><?= money($order['subtotal']) ?></span></div>
                <div class="d-flex justify-content-between"><span>GST</span><span><?= money($order['tax_amount']) ?></span></div>
                <div class="d-flex justify-content-between"><span>Delivery</span><span><?= money($order['delivery_charge']) ?></span></div>
                <div class="d-flex justify-content-between text-success"><span>Discount</span><span>- <?= money($order['discount_amount']) ?></span></div>
                <h4 class="d-flex justify-content-between border-top pt-3 mt-3"><span>Total</span><span><?= money($order['total_amount']) ?></span></h4>
            </div>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>
