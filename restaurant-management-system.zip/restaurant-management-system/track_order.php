<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Track Order';
$orderId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) redirect('orders.php');
$steps = ['Pending', 'Preparing', 'Out for Delivery', 'Delivered'];
$currentIndex = array_search($order['status'], $steps);
include 'includes/header.php';
?>
<section class="py-5 section-band"><div class="container"><h1 class="fw-bold">Track Order #<?= $order['id'] ?></h1></div></section>
<section class="py-5">
    <div class="container">
        <div class="content-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0">Current Status: <span id="liveStatus"><?= e($order['status']) ?></span></h5>
                <span class="badge text-bg-light">Auto updates every 5 seconds</span>
            </div>
            <div class="status-steps" id="statusSteps">
                <?php foreach ($steps as $index => $step): ?>
                    <div class="status-step <?= $currentIndex !== false && $index <= $currentIndex ? 'active' : '' ?>" data-status="<?= e($step) ?>">
                        <i class="bi bi-check-circle"></i><br><?= e($step) ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="d-flex flex-wrap gap-2 mt-4">
                <a href="invoice.php?id=<?= $order['id'] ?>" class="btn btn-outline-dark btn-sm">Download Invoice</a>
                <?php if ($order['status'] === 'Pending'): ?>
                    <a href="order_action.php?action=cancel&id=<?= $order['id'] ?>" onclick="return confirm('Cancel this order?')" class="btn btn-outline-danger btn-sm">Cancel Order</a>
                <?php endif; ?>
            </div>
            <p class="mt-4 mb-0">Delivery Address: <?= e($order['delivery_address']) ?></p>
        </div>
    </div>
</section>
<script>
const orderId = <?= $order['id'] ?>;
const steps = ['Pending', 'Preparing', 'Out for Delivery', 'Delivered'];

function refreshOrderStatus() {
    fetch('ajax/order_status.php?id=' + orderId)
        .then(response => response.json())
        .then(data => {
            if (!data.success) return;
            document.getElementById('liveStatus').textContent = data.status;
            const currentIndex = steps.indexOf(data.status);
            document.querySelectorAll('.status-step').forEach((step, index) => {
                step.classList.toggle('active', currentIndex !== -1 && index <= currentIndex);
            });
        })
        .catch(() => {});
}

setInterval(refreshOrderStatus, 5000);
</script>
<?php include 'includes/footer.php'; ?>
