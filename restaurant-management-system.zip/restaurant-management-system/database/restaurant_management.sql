CREATE DATABASE IF NOT EXISTS restaurant_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_management;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS coupons;
DROP TABLE IF EXISTS table_bookings;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS food_items;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admin;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE food_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(120) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    rating DECIMAL(2,1) DEFAULT 4.5,
    status ENUM('Available','Unavailable') DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_food_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cart_food FOREIGN KEY (food_id) REFERENCES food_items(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, food_id)
) ENGINE=InnoDB;

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    delivery_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending','Preparing','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
    payment_method VARCHAR(60) NOT NULL,
    payment_status ENUM('Pending','Paid','Failed') DEFAULT 'Pending',
    transaction_id VARCHAR(120),
    razorpay_order_id VARCHAR(100) DEFAULT NULL,
    delivery_address TEXT NOT NULL,
    coupon_code VARCHAR(50),
    discount_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_food FOREIGN KEY (food_id) REFERENCES food_items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    order_id             INT NOT NULL,
    razorpay_order_id    VARCHAR(100) NOT NULL,
    razorpay_payment_id  VARCHAR(100) DEFAULT NULL,
    razorpay_signature   VARCHAR(255) DEFAULT NULL,
    amount               DECIMAL(10,2) NOT NULL,
    currency             VARCHAR(10) DEFAULT 'INR',
    status               ENUM('created','paid','failed') DEFAULT 'created',
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    food_id INT NOT NULL,
    order_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_review_food FOREIGN KEY (food_id) REFERENCES food_items(id) ON DELETE CASCADE,
    CONSTRAINT fk_review_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    UNIQUE KEY unique_order_food_review (user_id, food_id, order_id)
) ENGINE=InnoDB;

CREATE TABLE coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_percent INT NOT NULL,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    expiry_date DATE,
    status ENUM('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(80) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE table_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    guests INT NOT NULL,
    status ENUM('Pending','Confirmed','Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO admin (username, password) VALUES ('admin', 'admin123');

INSERT INTO users (name, email, password, phone, address) VALUES
('Demo User', 'user@example.com', 'user123', '9876543210', 'Ring Road, Surat, Gujarat');

INSERT INTO categories (name, status) VALUES
('Veg', 'Active'),
('Non-Veg', 'Active'),
('Drinks', 'Active'),
('Desserts', 'Active');

INSERT INTO food_items (category_id, name, description, price, image, rating, status) VALUES
(1, 'Paneer Tikka Bowl', 'Smoky paneer, basmati rice, mint chutney and crisp salad.', 249.00, 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=80', 4.7, 'Available'),
(1, 'Veg Cheese Burger', 'Loaded vegetable patty with cheese, lettuce and house sauce.', 159.00, 'https://images.unsplash.com/photo-1520072959219-c595dc870360?auto=format&fit=crop&w=900&q=80', 4.5, 'Available'),
(2, 'Chicken Biryani', 'Aromatic rice cooked with tender chicken and traditional spices.', 299.00, 'https://images.unsplash.com/photo-1701579231349-d7459c40919d?auto=format&fit=crop&w=900&q=80', 4.8, 'Available'),
(2, 'Butter Chicken Meal', 'Creamy butter chicken served with naan and jeera rice.', 349.00, 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=80', 4.6, 'Available'),
(3, 'Mango Mojito', 'Fresh mango, mint, lemon and soda served chilled.', 119.00, 'https://images.unsplash.com/photo-1546171753-97d7676e4602?auto=format&fit=crop&w=900&q=80', 4.4, 'Available'),
(3, 'Cold Coffee', 'Creamy cold coffee topped with chocolate drizzle.', 139.00, 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=80', 4.5, 'Available'),
(4, 'Chocolate Brownie', 'Warm brownie with rich chocolate sauce.', 129.00, 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=80', 4.6, 'Available'),
(4, 'Gulab Jamun', 'Classic Indian dessert served warm.', 99.00, 'https://images.unsplash.com/photo-1601303516534-4a7c33230fbc?auto=format&fit=crop&w=900&q=80', 4.3, 'Available');

INSERT INTO coupons (code, discount_percent, min_order_amount, expiry_date, status) VALUES
('BCA10', 10, 199.00, '2027-12-31', 'Active'),
('FOOD20', 20, 499.00, '2027-12-31', 'Active');

INSERT INTO settings (setting_key, setting_value) VALUES
('restaurant_name', 'BCA Bistro'),
('restaurant_phone', '+91 98765 43210'),
('restaurant_address', 'Ring Road, Surat, Gujarat'),
('upi_id', 'bca-bistro@upi'),
('gst_percent', '5'),
('delivery_charge', '30'),
('free_delivery_above', '799');
