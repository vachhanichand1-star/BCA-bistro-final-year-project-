-- ============================================================
-- Razorpay Payment Gateway – Database Migration
-- ============================================================
-- Run this file in phpMyAdmin (or MySQL CLI) ONCE.
-- It is SAFE to run on an existing database – no data is lost.
-- ============================================================

USE restaurant_management;

-- Step 1: Add razorpay_order_id column to the orders table
--         (stores the Razorpay order ID returned by their API)
ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS razorpay_order_id VARCHAR(100) DEFAULT NULL AFTER transaction_id;

-- Step 2: Create a dedicated payments table to store all
--         Razorpay transaction details
CREATE TABLE IF NOT EXISTS payments (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    order_id             INT NOT NULL,
    razorpay_order_id    VARCHAR(100) NOT NULL,
    razorpay_payment_id  VARCHAR(100) DEFAULT NULL,
    razorpay_signature   VARCHAR(255) DEFAULT NULL,
    amount               DECIMAL(10,2) NOT NULL,
    currency             VARCHAR(10) DEFAULT 'INR',
    -- status: created = payment window opened, paid = success, failed = failed/cancelled
    status               ENUM('created','paid','failed') DEFAULT 'created',
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
