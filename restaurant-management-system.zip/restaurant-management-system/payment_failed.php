<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();

$pageTitle = 'Payment Failed';
$orderId   = (int) ($_GET['id']        ?? 0);
$cancelled = (bool) ($_GET['cancelled'] ?? false); // true if user dismissed popup

// Try to load order info (may not exist if something went very wrong)
$order = null;
if ($orderId) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$orderId, $_SESSION['user_id']]);
    $order = $stmt->fetch();
}

include 'includes/header.php';
?>

<style>
/* ── Payment Failed Page Styles ──────────────────────────── */
.failed-hero {
    min-height: 85vh;
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #1a0a0a 0%, #2d1515 50%, #1a0a0a 100%);
    position: relative;
    overflow: hidden;
}

.failed-hero::before {
    content: '';
    position: absolute;
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(239,68,68,0.1) 0%, transparent 70%);
    top: -100px;
    left: -50px;
    border-radius: 50%;
}
.failed-hero::after {
    content: '';
    position: absolute;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(239,68,68,0.07) 0%, transparent 70%);
    bottom: -80px;
    right: -100px;
    border-radius: 50%;
}

.failed-card {
    background: rgba(255,255,255,0.04);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(239,68,68,0.25);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    max-width: 560px;
    margin: 0 auto;
    color: #fff;
    position: relative;
    z-index: 1;
}

/* Animated X icon */
.x-circle {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    box-shadow: 0 0 40px rgba(239,68,68,0.35);
    animation: shake 0.5s 0.3s ease both;
}

@keyframes shake {
    0%,100% { transform: translateX(0); }
    20%      { transform: translateX(-6px); }
    40%      { transform: translateX(6px); }
    60%      { transform: translateX(-4px); }
    80%      { transform: translateX(4px); }
}

.x-circle i {
    font-size: 2.8rem;
    color: #fff;
}

.failed-title {
    font-size: 2rem;
    font-weight: 800;
    color: #fff;
    margin-bottom: 0.25rem;
}

.failed-subtitle {
    color: rgba(255,255,255,0.55);
    font-size: 1rem;
    margin-bottom: 2rem;
}

.reason-box {
    background: rgba(239,68,68,0.1);
    border: 1px solid rgba(239,68,68,0.2);
    border-radius: 12px;
    padding: 1rem 1.25rem;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    color: rgba(255,255,255,0.7);
    text-align: left;
}
.reason-box ul {
    margin: 0.5rem 0 0;
    padding-left: 1.2rem;
}
.reason-box li { margin-bottom: 0.3rem; }

.info-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 0.35rem 0.9rem;
    font-size: 0.85rem;
    color: rgba(255,255,255,0.6);
    margin-bottom: 1.5rem;
}

.btn-retry {
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 0.75rem 1.75rem;
    font-weight: 700;
    text-decoration: none;
    display: inline-block;
    transition: transform 0.2s, box-shadow 0.2s;
}
.btn-retry:hover {
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(239,68,68,0.35);
}

.btn-cod {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
    border-radius: 12px;
    padding: 0.75rem 1.75rem;
    font-weight: 600;
    text-decoration: none;
    display: inline-block;
    transition: all 0.2s;
}
.btn-cod:hover {
    background: rgba(255,255,255,0.14);
    color: #fff;
}

.btn-ghost {
    color: rgba(255,255,255,0.45);
    font-size: 0.9rem;
    text-decoration: none;
    transition: color 0.2s;
}
.btn-ghost:hover { color: rgba(255,255,255,0.75); }
</style>

<section class="failed-hero">
    <div class="container py-5">
        <div class="failed-card text-center">

            <!-- X icon with shake animation -->
            <div class="x-circle">
                <i class="bi bi-x-lg"></i>
            </div>

            <h1 class="failed-title">
                <?= $cancelled ? 'Payment Cancelled' : 'Payment Failed' ?>
            </h1>
            <p class="failed-subtitle">
                <?php if ($cancelled): ?>
                    You cancelled the payment. <br>Your cart items are still saved.
                <?php else: ?>
                    Something went wrong with your payment. <br>Don't worry — no money has been deducted.
                <?php endif; ?>
            </p>

            <?php if ($order): ?>
            <div class="info-pill">
                <i class="bi bi-receipt"></i>
                Order #<?= $order['id'] ?> &nbsp;|&nbsp;
                <?= money($order['total_amount']) ?>
            </div>
            <?php endif; ?>

            <!-- Common reasons why payment fails -->
            <?php if (!$cancelled): ?>
            <div class="reason-box">
                <strong style="color:rgba(255,255,255,0.85);">Common reasons for failure:</strong>
                <ul>
                    <li>Card declined or insufficient balance</li>
                    <li>Incorrect OTP or card details entered</li>
                    <li>Bank-side timeout or network issue</li>
                    <li>Daily transaction limit exceeded</li>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center mb-4">
                <a href="checkout.php" class="btn-retry">
                    <i class="bi bi-arrow-repeat me-1"></i>
                    <?= $cancelled ? 'Back to Checkout' : 'Try Again' ?>
                </a>
                <a href="checkout.php" class="btn-cod"
                   onclick="document.cookie='preferred_payment=cod;path=/'">
                    <i class="bi bi-cash-coin me-1"></i> Pay on Delivery
                </a>
            </div>

            <a href="orders.php" class="btn-ghost">
                <i class="bi bi-list-ul me-1"></i> View My Orders
            </a>

            <p class="mt-4 mb-0" style="color:rgba(255,255,255,0.3);font-size:0.78rem;">
                If money was deducted, it will be auto-refunded by your bank within 5–7 days.
            </p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
