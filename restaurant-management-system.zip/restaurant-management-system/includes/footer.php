</main>
<footer class="footer-band mt-5 py-4">
    <div class="container d-flex flex-column flex-md-row justify-content-between gap-3">
        <div>
            <h5 class="fw-bold mb-1">BCA Bistro</h5>
            <p class="mb-0 text-secondary">Fresh food, simple ordering, fast service.</p>
        </div>
        <div class="text-secondary">
            <span class="me-3"><i class="bi bi-telephone"></i> +91 99138 36339</span>
            <span><i class="bi bi-geo-alt"></i> Surat, Gujarat</span>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
