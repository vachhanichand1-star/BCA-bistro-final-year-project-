<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();

$pageTitle = 'Payment Successful';
$orderId   = (int) ($_GET['id'] ?? 0);

// Load order + payment details in one query
$stmt = $pdo->prepare(
    "SELECT o.*, p.razorpay_payment_id, p.razorpay_order_id AS rz_order_id, p.currency
     FROM orders o
     LEFT JOIN payments p ON p.order_id = o.id
     WHERE o.id = ? AND o.user_id = ?"
);
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) redirect('orders.php');

include 'includes/header.php';
?>

<style>
/* ── Payment Success Page Styles ─────────────────────────── */
.success-hero {
    min-height: 85vh;
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
    position: relative;
    overflow: hidden;
}

.success-hero::before {
    content: '';
    position: absolute;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(52,211,153,0.12) 0%, transparent 70%);
    top: -100px;
    right: -100px;
    border-radius: 50%;
}

.success-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(52,211,153,0.25);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    max-width: 560px;
    margin: 0 auto;
    color: #fff;
    position: relative;
    z-index: 1;
}

/* Animated success checkmark */
.check-circle {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: linear-gradient(135deg, #34d399, #059669);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    box-shadow: 0 0 40px rgba(52,211,153,0.4);
    animation: popIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) both;
}

@keyframes popIn {
    0%   { transform: scale(0); opacity: 0; }
    70%  { transform: scale(1.15); }
    100% { transform: scale(1); opacity: 1; }
}

.check-circle i {
    font-size: 2.8rem;
    color: #fff;
    animation: drawCheck 0.4s 0.4s ease both;
}

@keyframes drawCheck {
    0%   { opacity: 0; transform: scale(0.5); }
    100% { opacity: 1; transform: scale(1); }
}

/* Ripple rings around circle */
.ripple-ring {
    position: absolute;
    border-radius: 50%;
    border: 2px solid rgba(52,211,153,0.3);
    animation: ripple 2s ease-out infinite;
}
.ripple-ring:nth-child(1) { width: 120px; height: 120px; animation-delay: 0s; }
.ripple-ring:nth-child(2) { width: 150px; height: 150px; animation-delay: 0.4s; }
.ripple-ring:nth-child(3) { width: 180px; height: 180px; animation-delay: 0.8s; }

@keyframes ripple {
    0%   { transform: scale(0.8); opacity: 1; }
    100% { transform: scale(1.4); opacity: 0; }
}

.icon-wrapper {
    position: relative;
    width: 100px;
    height: 100px;
    margin: 0 auto 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

.success-title {
    font-size: 2rem;
    font-weight: 800;
    color: #fff;
    margin-bottom: 0.25rem;
}

.success-subtitle {
    color: rgba(255,255,255,0.65);
    font-size: 1rem;
    margin-bottom: 2rem;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    font-size: 0.925rem;
}
.detail-row:last-of-type { border-bottom: none; }
.detail-label { color: rgba(255,255,255,0.55); }
.detail-value { color: #fff; font-weight: 600; }
.detail-value.amount { color: #34d399; font-size: 1.2rem; }

.pid-badge {
    background: rgba(52,211,153,0.1);
    border: 1px solid rgba(52,211,153,0.3);
    border-radius: 8px;
    padding: 0.4rem 0.9rem;
    font-family: monospace;
    font-size: 0.82rem;
    color: #6ee7b7;
    word-break: break-all;
}

.btn-success-pg {
    background: linear-gradient(135deg, #34d399, #059669);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 0.75rem 1.75rem;
    font-weight: 700;
    text-decoration: none;
    display: inline-block;
    transition: transform 0.2s, box-shadow 0.2s;
}
.btn-success-pg:hover {
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(52,211,153,0.35);
}

.btn-outline-pg {
    border: 1px solid rgba(255,255,255,0.25);
    color: rgba(255,255,255,0.8);
    border-radius: 12px;
    padding: 0.75rem 1.75rem;
    font-weight: 600;
    text-decoration: none;
    display: inline-block;
    transition: all 0.2s;
}
.btn-outline-pg:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
    border-color: rgba(255,255,255,0.5);
}

/* Confetti decoration */
.confetti-dot {
    position: absolute;
    border-radius: 2px;
    animation: confettiFall linear infinite;
}
@keyframes confettiFall {
    0%   { transform: translateY(-20px) rotate(0deg); opacity: 1; }
    100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
}
</style>

<section class="success-hero">
    <!-- Floating confetti decorations -->
    <div class="confetti-dot" style="width:8px;height:8px;background:#34d399;top:10%;left:15%;animation-duration:4s;animation-delay:0s;"></div>
    <div class="confetti-dot" style="width:6px;height:6px;background:#fbbf24;top:20%;left:80%;animation-duration:5s;animation-delay:1s;"></div>
    <div class="confetti-dot" style="width:10px;height:10px;background:#a78bfa;top:5%;left:60%;animation-duration:3.5s;animation-delay:0.5s;"></div>
    <div class="confetti-dot" style="width:7px;height:7px;background:#f87171;top:30%;left:90%;animation-duration:4.5s;animation-delay:2s;"></div>
    <div class="confetti-dot" style="width:5px;height:5px;background:#34d399;top:60%;left:5%;animation-duration:6s;animation-delay:1.5s;"></div>

    <div class="container py-5">
        <div class="success-card text-center">

            <!-- Animated check icon with ripple rings -->
            <div class="icon-wrapper mx-auto mb-4">
                <div class="ripple-ring"></div>
                <div class="ripple-ring"></div>
                <div class="ripple-ring"></div>
                <div class="check-circle">
                    <i class="bi bi-check-lg"></i>
                </div>
            </div>

            <h1 class="success-title">Payment Successful!</h1>
            <p class="success-subtitle">Your order has been placed and confirmed. 🎉</p>

            <!-- Order Details -->
            <div class="mb-4">
                <div class="detail-row">
                    <span class="detail-label">Order ID</span>
                    <span class="detail-value">#<?= $order['id'] ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Amount Paid</span>
                    <span class="detail-value amount"><?= money($order['total_amount']) ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Payment Method</span>
                    <span class="detail-value">
                        <i class="bi bi-credit-card me-1"></i> Razorpay
                    </span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Payment Status</span>
                    <span class="detail-value">
                        <span class="badge" style="background:rgba(52,211,153,0.2);color:#34d399;border:1px solid #34d399;">
                            ✓ Paid
                        </span>
                    </span>
                </div>
                <?php if ($order['razorpay_payment_id']): ?>
                <div class="detail-row flex-column align-items-start gap-2">
                    <span class="detail-label">Razorpay Payment ID</span>
                    <span class="pid-badge"><?= e($order['razorpay_payment_id']) ?></span>
                </div>
                <?php endif; ?>
                <div class="detail-row">
                    <span class="detail-label">Delivery Address</span>
                    <span class="detail-value text-end" style="max-width:55%;font-size:0.85rem;">
                        <?= e($order['delivery_address']) ?>
                    </span>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center">
                <a href="track_order.php?id=<?= $order['id'] ?>" class="btn-success-pg">
                    <i class="bi bi-geo-alt me-1"></i> Track Order
                </a>
                <a href="orders.php" class="btn-outline-pg">
                    <i class="bi bi-list-ul me-1"></i> All Orders
                </a>
            </div>

            <p class="mt-4 mb-0" style="color:rgba(255,255,255,0.4);font-size:0.8rem;">
                A confirmation has been recorded. Keep your Payment ID for reference.
            </p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
