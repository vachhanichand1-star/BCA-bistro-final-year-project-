<?php
require_once 'config/database.php';
require_once 'config/helpers.php';
require_user();
$pageTitle = 'Checkout';

$userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([$_SESSION['user_id']]);
$user = $userStmt->fetch();

$stmt = $pdo->prepare("SELECT cart.*, f.name, f.price FROM cart JOIN food_items f ON f.id = cart.food_id WHERE cart.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$cartItems = $stmt->fetchAll();
if (!$cartItems) {
    flash('error', 'Your cart is empty.');
    redirect('cart.php');
}

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$discount = 0;
$couponCode = '';
$hasError = false;
$gstPercent = (float) get_setting($pdo, 'gst_percent', '5');
$deliveryCharge = (float) get_setting($pdo, 'delivery_charge', '30');
$freeDeliveryAbove = (float) get_setting($pdo, 'free_delivery_above', '799');
$upiId = get_setting($pdo, 'upi_id', 'bca-bistro@upi');
$taxAmount = $subtotal * ($gstPercent / 100);
$deliveryAmount = $subtotal >= $freeDeliveryAbove ? 0 : $deliveryCharge;
$total = $subtotal + $taxAmount + $deliveryAmount;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = trim($_POST['address']);
    $paymentMethod = $_POST['payment_method'];
    $transactionId = trim($_POST['transaction_id'] ?? '');
    $couponCode = strtoupper(trim($_POST['coupon_code'] ?? ''));

    if ($couponCode) {
        $couponStmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND status = 'Active'");
        $couponStmt->execute([$couponCode]);
        $coupon = $couponStmt->fetch();
        if (!$coupon) {
            flash('error', 'Invalid coupon code.');
            $hasError = true;
        } elseif ($subtotal < (float) $coupon['min_order_amount']) {
            flash('error', 'Minimum order for this coupon is ' . money($coupon['min_order_amount']) . '.');
            $hasError = true;
        } elseif ($coupon['expiry_date'] && $coupon['expiry_date'] < date('Y-m-d')) {
            flash('error', 'This coupon has expired.');
            $hasError = true;
        } else {
            $discount = $subtotal * ($coupon['discount_percent'] / 100);
        }
    }

    $total = max(0, $subtotal + $taxAmount + $deliveryAmount - $discount);
    $paymentStatus = 'Pending';

    if ($paymentMethod === 'UPI Payment') {
        if ($transactionId === '') {
            flash('error', 'Please enter your UPI transaction/reference ID after payment.');
            $hasError = true;
        } else {
            $paymentStatus = 'Paid';
        }
    }

    if ($address && $paymentMethod && !$hasError) {
        $pdo->beginTransaction();
        $orderStmt = $pdo->prepare("INSERT INTO orders (user_id, subtotal, tax_amount, delivery_charge, total_amount, payment_method, payment_status, transaction_id, delivery_address, coupon_code, discount_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $orderStmt->execute([$_SESSION['user_id'], $subtotal, $taxAmount, $deliveryAmount, $total, $paymentMethod, $paymentStatus, $transactionId ?: null, $address, $couponCode ?: null, $discount]);
        $orderId = $pdo->lastInsertId();

        $itemStmt = $pdo->prepare("INSERT INTO order_items (order_id, food_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach ($cartItems as $item) {
            $itemStmt->execute([$orderId, $item['food_id'], $item['quantity'], $item['price']]);
        }

        $deleteStmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
        $deleteStmt->execute([$_SESSION['user_id']]);
        $pdo->commit();

        redirect('order_success.php?id=' . $orderId);
    }
}
include 'includes/header.php';
?>
<section class="py-5 section-band"><div class="container"><h1 class="fw-bold">Checkout</h1></div></section>
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="content-card p-4">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Delivery Address</label>
                            <textarea name="address" rows="4" class="form-control" required><?= e($user['address']) ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" id="payment_method" class="form-select" required onchange="togglePaymentBoxes()">
                                <option value="Cash on Delivery">Cash on Delivery</option>
                                <option value="UPI Payment">UPI Payment</option>
                                <option value="Card Demo">Card Demo</option>
                                <option value="Razorpay">💳 Razorpay (Online Payment)</option>
                            </select>
                            <small class="text-secondary">Pay securely via Razorpay — cards, UPI, netbanking & wallets accepted.</small>
                        </div>
                        <div id="upiBox" class="border rounded-2 p-3 mb-3 d-none">
                            <h6 class="fw-bold">Pay With UPI</h6>
                            <p class="mb-1">UPI ID: <strong><?= e($upiId) ?></strong></p>
                            <p class="mb-2">Amount: <strong><?= money($total) ?></strong></p>
                            <a id="upiPayLink" href="upi://pay?pa=<?= urlencode($upiId) ?>&pn=BCA%20Bistro&am=<?= urlencode(number_format($total, 2, '.', '')) ?>&cu=INR" class="btn btn-outline-dark btn-sm mb-3">
                                Open UPI App
                            </a>
                            <label class="form-label">UPI Transaction / Reference ID</label>
                            <input name="transaction_id" id="transaction_id" class="form-control" placeholder="Example: 412345678901">
                            <small class="text-secondary">After completing payment in your UPI app, paste the reference ID here.</small>
                        </div>
                        <!-- Razorpay Info Box (shown only when Razorpay is selected) -->
                        <div id="razorpayBox" class="border rounded-2 p-3 mb-3 d-none" style="border-color:rgba(83,131,236,0.4)!important;background:rgba(83,131,236,0.05);">
                            <h6 class="fw-bold"><i class="bi bi-shield-lock-fill text-primary me-1"></i> Secure Online Payment via Razorpay</h6>
                            <p class="mb-1 text-secondary">Amount to pay: <strong class="text-dark"><?= money($total) ?></strong></p>
                            <p class="mb-0 small text-secondary">
                                <i class="bi bi-check-circle-fill text-success me-1"></i>Supports Credit/Debit Cards, UPI, Netbanking, &amp; Wallets.<br>
                                <i class="bi bi-check-circle-fill text-success me-1"></i>100% secure — powered by Razorpay.
                            </p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Coupon Code</label>
                            <input name="coupon_code" class="form-control" placeholder="Try BCA10 or FOOD20">
                        </div>
                        <button id="placeOrderBtn" class="btn btn-brand">Place Order</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="content-card p-4">
                    <h4 class="fw-bold">Order Summary</h4>
                    <?php foreach ($cartItems as $item): ?>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span><?= e($item['name']) ?> x <?= $item['quantity'] ?></span>
                            <strong><?= money($item['price'] * $item['quantity']) ?></strong>
                        </div>
                    <?php endforeach; ?>
                    <div class="d-flex justify-content-between mt-3"><span>Subtotal</span><span><?= money($subtotal) ?></span></div>
                    <div class="d-flex justify-content-between"><span>GST (<?= e($gstPercent) ?>%)</span><span><?= money($taxAmount) ?></span></div>
                    <div class="d-flex justify-content-between"><span>Delivery</span><span><?= money($deliveryAmount) ?></span></div>
                    <div class="d-flex justify-content-between text-success"><span>Discount</span><span>- <?= money($discount) ?></span></div>
                    <h5 class="d-flex justify-content-between mt-3 border-top pt-3"><span>Total</span><span><?= money($total) ?></span></h5>
                    <small class="text-secondary">Free delivery above <?= money($freeDeliveryAbove) ?>.</small>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Razorpay Checkout JS Library -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
// ─── Toggle payment info boxes based on selected method ─────
function togglePaymentBoxes() {
    const method = document.getElementById('payment_method').value;
    const upiBox      = document.getElementById('upiBox');
    const razorpayBox = document.getElementById('razorpayBox');
    const txn         = document.getElementById('transaction_id');

    const isUpi      = method === 'UPI Payment';
    const isRazorpay = method === 'Razorpay';

    upiBox.classList.toggle('d-none', !isUpi);
    razorpayBox.classList.toggle('d-none', !isRazorpay);
    txn.required = isUpi;
}
document.addEventListener('DOMContentLoaded', togglePaymentBoxes);

// ─── Intercept form submit for Razorpay ─────────────────────
document.querySelector('form').addEventListener('submit', function(e) {
    const method = document.getElementById('payment_method').value;

    // Only intercept when Razorpay is selected; let other methods submit normally
    if (method !== 'Razorpay') return;

    e.preventDefault(); // stop normal form submission

    const address = document.querySelector('[name="address"]').value.trim();
    if (!address) {
        alert('Please enter your delivery address.');
        return;
    }

    const btn = document.getElementById('placeOrderBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Creating Order...';

    // Step 1: Call our PHP to create the order in DB + get Razorpay Order ID
    const formData = new FormData();
    formData.append('address',     address);
    formData.append('coupon_code', document.querySelector('[name="coupon_code"]').value || '');

    fetch('ajax/create_razorpay_order.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            // Step 2: Open Razorpay popup
            openRazorpayPopup(data);
        } else {
            alert('Error: ' + (data.message || 'Could not create order. Please try again.'));
            btn.disabled = false;
            btn.innerHTML = 'Place Order';
        }
    })
    .catch(() => {
        alert('Network error. Please check your connection and try again.');
        btn.disabled = false;
        btn.innerHTML = 'Place Order';
    });
});

// ─── Open Razorpay payment popup ─────────────────────────────
function openRazorpayPopup(data) {
    const options = {
        key:         data.key_id,          // Your Razorpay Key ID
        amount:      data.amount,          // Amount in paise (e.g. 50000 = Rs. 500)
        currency:    'INR',
        name:        'BCA Bistro',
        description: 'Food Order #' + data.order_id,
        image:       '',                   // Optional: URL to your logo
        order_id:    data.razorpay_order_id, // Razorpay Order ID from API

        // Pre-fill user details so they don't have to type again
        prefill: {
            name:    data.name,
            email:   data.email,
            contact: data.phone
        },

        theme: { color: '#c25b2e' }, // Match your brand color

        // Called automatically when payment succeeds
        handler: function(response) {
            // response contains: razorpay_payment_id, razorpay_order_id, razorpay_signature
            // Submit these to our backend for verification
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'razorpay_callback.php';

            const fields = {
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_order_id:   response.razorpay_order_id,
                razorpay_signature:  response.razorpay_signature,
                order_id:            data.order_id
            };

            // Create hidden inputs for each value
            for (const key in fields) {
                const input = document.createElement('input');
                input.type  = 'hidden';
                input.name  = key;
                input.value = fields[key];
                form.appendChild(input);
            }

            document.body.appendChild(form);
            form.submit(); // → goes to razorpay_callback.php
        },

        modal: {
            // Called when user closes/dismisses the Razorpay popup
            ondismiss: function() {
                window.location.href = 'payment_failed.php?id=' + data.order_id + '&cancelled=1';
            }
        }
    };

    const rzp = new Razorpay(options);

    // Called when payment fails inside the popup
    rzp.on('payment.failed', function(response) {
        window.location.href = 'payment_failed.php?id=' + data.order_id;
    });

    rzp.open(); // Show the Razorpay payment popup
}
</script>
<?php include 'includes/footer.php'; ?>
